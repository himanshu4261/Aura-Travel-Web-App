// ============================================
// INDIAN HOTELS DATASET
// ============================================
const IndianHotels = [];

function addHotel(name, city, state, starRating, rating, pricePerNight, amenities, imageUrl) {
    IndianHotels.push({
        _id: 'hotel_' + (IndianHotels.length + 1),
        name: name,
        location: { city: city, state: state },
        starRating: starRating,
        rating: { average: rating, count: Math.floor(Math.random() * 2000) + 100 },
        roomTypes: [{ name: 'Standard Room', price: { base: pricePerNight }, availableRooms: Math.floor(Math.random() * 20) + 5 }],
        amenities: amenities,
        images: [{ url: imageUrl }],
        description: 'A wonderful stay in ' + city + ', ' + state + '.',
        isActive: true
    });
}

// Luxury Hotels (5 Star)
addHotel('Taj Fort Aguada', 'Goa', 'Goa', 5, 4.7, 8000, ['Pool', 'Free WiFi', 'Spa', 'Beach Access', 'Restaurant', 'Bar', 'Gym'], 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg');
addHotel('The Oberoi Amarvilas', 'Agra', 'Uttar Pradesh', 5, 4.9, 9000, ['Pool', 'Free WiFi', 'Spa', 'Taj View', 'Fine Dining', 'Butler Service'], 'oberoyAmar.webp');
addHotel('The Leela Palace', 'New Delhi', 'Delhi', 5, 4.8, 8000, ['Pool', 'Free WiFi', 'Spa', 'Fine Dining', 'Airport Pickup', 'Concierge'], 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg');
addHotel('Rambagh Palace', 'Jaipur', 'Rajasthan', 5, 4.9, 10000, ['Pool', 'Free WiFi', 'Spa', 'Heritage', 'Royal Butler', 'Polo Bar'], 'rambaghpalace.avif');
addHotel('ITC Grand Chola', 'Chennai', 'Tamil Nadu', 5, 4.7, 10000, ['Pool', 'Free WiFi', 'Spa', 'Multiple Restaurants', 'Bar', 'Gym'], 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg');
addHotel('The Lalit', 'Mumbai', 'Maharashtra', 5, 4.5, 15000, ['Pool', 'Free WiFi', 'Spa', 'Airport Nearby', 'Restaurant', 'Bar'], 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg');
addHotel('Wildflower Hall', 'Shimla', 'Himachal Pradesh', 5, 4.8, 8000, ['Pool', 'Free WiFi', 'Spa', 'Mountain View', 'Hiking', 'Fine Dining'], 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg');
addHotel('Taj Lake Palace', 'Udaipur', 'Rajasthan', 5, 4.9, 30000, ['Pool', 'Free WiFi', 'Spa', 'Lake View', 'Boat Ride', 'Heritage'], 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg');

// Mid-Range Hotels (3-4 Star)
addHotel('Holiday Inn Resort', 'Goa', 'Goa', 4, 4.5, 6200, ['Pool', 'Free WiFi', 'Beach Access', 'Gym', 'Restaurant', 'Kids Club'], 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg');
addHotel('Lemon Tree Hotel', 'Jaipur', 'Rajasthan', 4, 4.3, 4500, ['Free WiFi', 'Pool', 'Restaurant', 'Gym', 'Business Center'], 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg');
addHotel('Fortune Park', 'Varanasi', 'Uttar Pradesh', 4, 4.2, 3800, ['Free WiFi', 'Restaurant', 'Ganga View', 'Spa', 'Travel Desk'], 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg');
addHotel('The Himalayan Resort', 'Manali', 'Himachal Pradesh', 4, 4.4, 5000, ['Free WiFi', 'Mountain View', 'Restaurant', 'Bonfire', 'Adventure Desk'], 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg');
addHotel('Spice Village', 'Thekkady', 'Kerala', 4, 4.6, 5500, ['Free WiFi', 'Pool', 'Restaurant', 'Spice Tour', 'Ayurveda Spa'], 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg');
addHotel('Sterling Ooty', 'Ooty', 'Tamil Nadu', 4, 4.3, 4800, ['Free WiFi', 'Valley View', 'Restaurant', 'Bonfire', 'Indoor Games'], 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg');
addHotel('Club Mahindra', 'Munnar', 'Kerala', 4, 4.4, 6000, ['Free WiFi', 'Pool', 'Tea Garden View', 'Restaurant', 'Spa', 'Activities'], 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg');
addHotel('WelcomHeritage', 'Jodhpur', 'Rajasthan', 4, 4.5, 7000, ['Free WiFi', 'Heritage', 'Restaurant', 'Mehrangarh View', 'Cultural Shows'], 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg');

// Budget Hotels (1-3 Star)
addHotel('Zostel Goa', 'Anjuna', 'Goa', 3, 4.3, 899, ['Free WiFi', 'Common Area', 'Events', 'Bike Rental', 'Cafe'], 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg');
addHotel('Moustache Hostel', 'Jaipur', 'Rajasthan', 3, 4.4, 599, ['Free WiFi', 'Common Area', 'Rooftop', 'City Tours', 'Cafe'], 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg');
addHotel('Vedanta Wake Up', 'Rishikesh', 'Uttarakhand', 3, 4.2, 799, ['Free WiFi', 'Ganga View', 'Yoga Classes', 'Rafting Desk', 'Cafe'], 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg');
addHotel('Backpacker Panda', 'Kasol', 'Himachal Pradesh', 2, 4.0, 499, ['Free WiFi', 'Common Area', 'Bonfire', 'Hiking Trips'], 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg');
addHotel('Hotel Ganges View', 'Varanasi', 'Uttar Pradesh', 3, 4.1, 1500, ['Free WiFi', 'Ganga View', 'Restaurant', 'Boat Tours'], 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg');
addHotel('Jungle Lodge Resort', 'Bandhavgarh', 'Madhya Pradesh', 3, 4.3, 3500, ['Free WiFi', 'Safari', 'Restaurant', 'Nature Walks', 'Bonfire'], 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg');

// Boutique & Heritage
addHotel('Suryagarh', 'Jaisalmer', 'Rajasthan', 5, 4.8, 16000, ['Pool', 'Free WiFi', 'Desert Safari', 'Spa', 'Heritage', 'Fine Dining'], 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg');
addHotel('Neemrana Fort Palace', 'Neemrana', 'Rajasthan', 4, 4.5, 8000, ['Pool', 'Free WiFi', 'Heritage', 'Zip Line', 'Vintage Car Ride'], 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg');
addHotel('Orange County Resort', 'Coorg', 'Karnataka', 5, 4.7, 14000, ['Pool', 'Free WiFi', 'Coffee Plantation', 'Spa', 'Fine Dining', 'Nature Walks'], 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg');
addHotel('Glenburn Tea Estate', 'Darjeeling', 'West Bengal', 5, 4.9, 20000, ['Free WiFi', 'Tea Garden', 'Kanchenjunga View', 'Fine Dining', 'Tea Tasting'], 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg');

// Beach Resorts
addHotel('Park Hyatt Resort', 'Goa', 'Goa', 5, 4.6, 11000, ['Pool', 'Free WiFi', 'Beach', 'Spa', 'Water Sports', 'Multiple Restaurants'], 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg');
addHotel('Nirvana on the Beach', 'Gokarna', 'Karnataka', 3, 4.2, 2500, ['Free WiFi', 'Beach', 'Yoga', 'Restaurant', 'Bonfire'], 'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg');
addHotel('Barefoot Resort', 'Havelock', 'Andaman & Nicobar', 4, 4.7, 9000, ['Free WiFi', 'Beach', 'Scuba Diving', 'Restaurant', 'Nature Walks'], 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg');

// Mountain Resorts
addHotel('Shivadya Resort', 'Manali', 'Himachal Pradesh', 4, 4.3, 4200, ['Free WiFi', 'Mountain View', 'Restaurant', 'Bonfire', 'Skiing Nearby'], 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg');
addHotel('The Grand Dragon', 'Leh', 'Ladakh', 5, 4.6, 13000, ['Free WiFi', 'Mountain View', 'Restaurant', 'Oxygen Bar', 'Cultural Tours'], 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg');

console.log('✅ ' + IndianHotels.length + ' Indian Hotels Loaded!');

if (typeof window !== 'undefined') {
    window.IndianHotels = IndianHotels;
}
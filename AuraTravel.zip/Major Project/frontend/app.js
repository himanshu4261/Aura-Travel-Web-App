/* ============================================
   AURA TRAVEL - FULLY WORKING VERSION
   All pages, buttons, features functional
   ============================================ */

// ============================================
// CONFIGURATION
// ============================================
const API_BASE_URL = 'http://localhost:5000/api';
const USE_MOCK_DATA = false;

// ============================================
// DEMO USER
// ============================================
const DEMO_USER = {
    _id: 'user_demo_001',
    name: 'Himanshu Patel',
    email: 'himanshu11@gmail.com',
    password: '111',
    phone: '+91 98765 43210',
    location: 'Mumbai, India',
    role: 'user'
};

// Sample data
const SAMPLE_NOTIFICATIONS = [
    { id: 1, title: '🎉 Welcome!', msg: 'Explore 400+ Indian destinations.', time: 'Just now', unread: true },
    { id: 2, title: '🏨 New Hotels', msg: 'Luxury hotels added in Goa & Kerala.', time: '2h ago', unread: true },
    { id: 3, title: '💰 Special Offer', msg: '20% off Golden Triangle package.', time: '1d ago', unread: true },
    { id: 4, title: '🌟 Trending', msg: 'Kedarnath is popular this week!', time: '2d ago', unread: false },
    { id: 5, title: '📅 Travel Tip', msg: 'Best time for Leh: June-September.', time: '3d ago', unread: false }
];

const CATEGORY_INFO = [
    { id: 'temples', name: 'Temples', icon: 'fa-om', desc: 'Sacred temples & pilgrimage', color: '#f59e0b' },
    { id: 'mountains', name: 'Mountains', icon: 'fa-mountain', desc: 'Hill stations & adventures', color: '#10b981' },
    { id: 'beaches', name: 'Beaches', icon: 'fa-umbrella-beach', desc: 'Coastal getaways', color: '#3b82f6' },
    { id: 'monuments', name: 'Monuments', icon: 'fa-landmark', desc: 'Historical & UNESCO sites', color: '#8b5cf6' },
    { id: 'wildlife', name: 'Wildlife', icon: 'fa-paw', desc: 'National parks & safaris', color: '#ef4444' },
    { id: 'backwaters', name: 'Backwaters', icon: 'fa-water', desc: 'Houseboats & serenity', color: '#06b6d4' },
    { id: 'heritage', name: 'Heritage', icon: 'fa-archway', desc: 'Royal palaces & culture', color: '#f97316' }
];

const WEATHER_DATA = {
    'delhi': { temp: 32, cond: 'Sunny', humidity: 45, wind: 12, icon: 'fa-sun', feels: 34 },
    'mumbai': { temp: 30, cond: 'Humid', humidity: 70, wind: 8, icon: 'fa-cloud', feels: 33 },
    'goa': { temp: 31, cond: 'Sunny', humidity: 65, wind: 10, icon: 'fa-sun', feels: 34 },
    'jaipur': { temp: 35, cond: 'Hot', humidity: 30, wind: 6, icon: 'fa-sun', feels: 37 },
    'agra': { temp: 33, cond: 'Sunny', humidity: 40, wind: 8, icon: 'fa-sun', feels: 35 },
    'manali': { temp: 18, cond: 'Cool', humidity: 40, wind: 5, icon: 'fa-cloud-sun', feels: 17 },
    'leh': { temp: 12, cond: 'Cold', humidity: 30, wind: 8, icon: 'fa-snowflake', feels: 10 },
    'shimla': { temp: 20, cond: 'Pleasant', humidity: 45, wind: 6, icon: 'fa-cloud-sun', feels: 19 },
    'varanasi': { temp: 34, cond: 'Hot', humidity: 50, wind: 7, icon: 'fa-sun', feels: 36 },
    'kolkata': { temp: 31, cond: 'Humid', humidity: 75, wind: 9, icon: 'fa-cloud', feels: 35 },
    'chennai': { temp: 33, cond: 'Hot', humidity: 70, wind: 10, icon: 'fa-sun', feels: 37 },
    'bengaluru': { temp: 26, cond: 'Pleasant', humidity: 55, wind: 8, icon: 'fa-cloud-sun', feels: 27 },
    'hyderabad': { temp: 33, cond: 'Hot', humidity: 45, wind: 7, icon: 'fa-sun', feels: 35 },
    'udaipur': { temp: 30, cond: 'Sunny', humidity: 35, wind: 6, icon: 'fa-sun', feels: 31 },
    'darjeeling': { temp: 15, cond: 'Cool', humidity: 60, wind: 5, icon: 'fa-cloud', feels: 14 },
    'ooty': { temp: 18, cond: 'Pleasant', humidity: 55, wind: 6, icon: 'fa-cloud-sun', feels: 17 },
    'rishikesh': { temp: 28, cond: 'Sunny', humidity: 45, wind: 7, icon: 'fa-sun', feels: 29 },
    'amritsar': { temp: 30, cond: 'Sunny', humidity: 40, wind: 6, icon: 'fa-sun', feels: 31 },
    'srinagar': { temp: 16, cond: 'Cool', humidity: 50, wind: 5, icon: 'fa-cloud-sun', feels: 15 },
    'munnar': { temp: 17, cond: 'Cool', humidity: 65, wind: 5, icon: 'fa-cloud', feels: 16 }
};

// ============================================
// WAIT FOR DATASET
// ============================================
function waitForDataset() {
    return new Promise(function(resolve) {
        if (typeof IndianDestinations !== 'undefined' && IndianDestinations.length > 0) {
            resolve();
        } else {
            var check = setInterval(function() {
                if (typeof IndianDestinations !== 'undefined' && IndianDestinations.length > 0) {
                    clearInterval(check);
                    resolve();
                }
            }, 100);
        }
    });
}

// ============================================
// APP STATE
// ============================================
var AppState = {
    currentPage: 'home',
    currentUser: null,
    token: null,
    savedDestinations: [],
    notifications: SAMPLE_NOTIFICATIONS.map(function(n) { return Object.assign({}, n); }),
    filters: { category: 'all', search: '' },
    showingAll: false,
    showingCategories: false,
    itineraryTab: 'upcoming',
    reviewFilter: 'all',
    hotelSearch: '',
    hotelFilter: 'all',
    
    get allDestinations() {
        return typeof IndianDestinations !== 'undefined' ? IndianDestinations : [];
    },
    get isLoggedIn() {
        return !!this.token && !!this.currentUser;
    },
    get unreadCount() {
        return this.notifications.filter(function(n) { return n.unread; }).length;
    }
};

// Save/load state
function saveState() {
    localStorage.setItem('aura_token', AppState.token || '');
    localStorage.setItem('aura_user', JSON.stringify(AppState.currentUser || null));
    localStorage.setItem('aura_wishlist', JSON.stringify(AppState.savedDestinations));
}

function loadState() {
    var t = localStorage.getItem('aura_token');
    var u = localStorage.getItem('aura_user');
    var w = localStorage.getItem('aura_wishlist');
    if (t && u) {
        AppState.token = t;
        try { AppState.currentUser = JSON.parse(u); } catch(e) { AppState.currentUser = null; }
    }
    if (w) {
        try { AppState.savedDestinations = JSON.parse(w); } catch(e) { AppState.savedDestinations = []; }
    }
}

// ============================================
// UTILS
// ============================================
function formatCurrency(amount) {
    if (!amount) return '₹0';
    return '₹' + amount.toLocaleString('en-IN');
}

function showToast(msg, type) {
    var t = document.querySelector('.toast');
    if (t) t.remove();
    t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    t.style.cssText = 'position:fixed;bottom:100px;left:50%;transform:translateX(-50%);background:' + (type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6') + ';color:white;padding:12px 24px;border-radius:50px;font-weight:600;z-index:9999;box-shadow:0 8px 25px rgba(0,0,0,0.2);';
    document.body.appendChild(t);
    setTimeout(function() { t.remove(); }, 3000);
}

function showLoading(s) {
    var l = document.getElementById('loadingScreen');
    if (l) { l.classList.toggle('hidden', !s); }
}

// ============================================
// API
// ============================================
var API = {
    stats: function() {
        return { destinations: AppState.allDestinations.length, states: 28, avgBudget: 6988 };
    },
    destinations: function(params) {
        var d = AppState.allDestinations.slice();
        if (params && params.category && params.category !== 'all') {
            d = d.filter(function(x) { return x.category === params.category; });
        }
        if (params && params.search) {
            var q = params.search.toLowerCase();
            d = d.filter(function(x) { return x.name.toLowerCase().indexOf(q) !== -1 || x.state.toLowerCase().indexOf(q) !== -1; });
        }
        return d;
    },
    destination: function(id) {
        return AppState.allDestinations.find(function(x) { return x._id === id; });
    },
    hotels: function() {
        return typeof IndianHotels !== 'undefined' && IndianHotels.length > 0 ? IndianHotels : [
            { _id:'h1',name:'Taj Fort Aguada',location:{city:'Goa',state:'Goa'},starRating:5,rating:{average:4.7},roomTypes:[{price:{base:8500}}],amenities:['Pool','WiFi','Spa','Beach'],images:[{url:'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg'}] },
            { _id:'h2',name:'Oberoi Amarvilas',location:{city:'Agra',state:'UP'},starRating:5,rating:{average:4.9},roomTypes:[{price:{base:25000}}],amenities:['Pool','Spa','Taj View'],images:[{url:'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg'}] },
            { _id:'h3',name:'Zostel Goa',location:{city:'Anjuna',state:'Goa'},starRating:3,rating:{average:4.3},roomTypes:[{price:{base:899}}],amenities:['WiFi','Common Area'],images:[{url:'https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg'}] },
            { _id:'h4',name:'Holiday Inn',location:{city:'Goa',state:'Goa'},starRating:4,rating:{average:4.5},roomTypes:[{price:{base:6200}}],amenities:['WiFi','Beach','Gym'],images:[{url:'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg'}] }
        ];
    },
    weather: function(city) {
        var c = city.toLowerCase();
        return WEATHER_DATA[c] || { temp: 28, cond: 'Clear', humidity: 50, wind: 10, icon: 'fa-sun', feels: 29 };
    },
    login: function(email, password) {
        if (email === DEMO_USER.email && password === DEMO_USER.password) {
            return { success: true, user: DEMO_USER };
        }
        var users = JSON.parse(localStorage.getItem('aura_registered') || '[]');
        var found = users.find(function(u) { return u.email === email && u.password === password; });
        if (found) return { success: true, user: found };
        return { success: false, msg: 'Invalid credentials' };
    },
    register: function(data) {
        var users = JSON.parse(localStorage.getItem('aura_registered') || '[]');
        if (users.find(function(u) { return u.email === data.email; }) || data.email === DEMO_USER.email) {
            return { success: false, msg: 'Email already exists' };
        }
        var newUser = { _id: 'u' + Date.now(), name: data.name, email: data.email, password: data.password, phone: data.phone || '', location: 'India', role: 'user' };
        users.push(newUser);
        localStorage.setItem('aura_registered', JSON.stringify(users));
        return { success: true, user: newUser };
    },
    toggleWishlist: function(id) {
        var idx = AppState.savedDestinations.indexOf(id);
        if (idx === -1) AppState.savedDestinations.push(id);
        else AppState.savedDestinations.splice(idx, 1);
        saveState();
        return { saved: idx === -1, list: AppState.savedDestinations };
    }
};

// ============================================
// AUTH MODAL
// ============================================
var AuthModal = {
    show: function(mode) {
        mode = mode || 'login';
        var ex = document.getElementById('authModal');
        if (ex) ex.remove();
        
        var d = document.createElement('div');
        d.id = 'authModal';
        d.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:10000;display:flex;align-items:center;justify-content:center;';
        d.innerHTML = '<div style="background:white;border-radius:20px;width:90%;max-width:400px;padding:2rem;">' +
            '<div style="display:flex;justify-content:space-between;margin-bottom:1.5rem;"><h2 style="margin:0;">' + (mode==='login'?'Sign In':'Sign Up') + '</h2><button id="authClose" style="border:none;background:none;font-size:1.5rem;cursor:pointer;">&times;</button></div>' +
            (mode==='login'?'<div style="background:#eff6ff;padding:10px;border-radius:10px;margin-bottom:1rem;text-align:center;font-size:0.85rem;">Demo: <b>himanshu11@gmail.com</b> / <b>111</b></div>':'') +
            '<form id="authForm">' +
            (mode==='register'?'<div style="margin-bottom:1rem;"><label style="font-size:0.85rem;font-weight:500;">Name</label><input type="text" id="authName" required style="width:100%;padding:10px;border:1px solid #e5e7eb;border-radius:8px;margin-top:4px;"></div>':'') +
            '<div style="margin-bottom:1rem;"><label style="font-size:0.85rem;font-weight:500;">Email</label><input type="email" id="authEmail" required placeholder="Enter your email" style="width:100%;padding:10px;border:1px solid #e5e7eb;border-radius:8px;margin-top:4px;"></div>' +
            '<div style="margin-bottom:1rem;"><label style="font-size:0.85rem;font-weight:500;">Password</label><input type="password" id="authPassword" required placeholder="Enter your password" style="width:100%;padding:10px;border:1px solid #e5e7eb;border-radius:8px;margin-top:4px;"></div>' +
            '<button type="submit" style="width:100%;padding:12px;background:linear-gradient(135deg,#2563eb,#7c3aed);color:white;border:none;border-radius:10px;font-size:1rem;font-weight:600;cursor:pointer;">' + (mode==='login'?'Sign In':'Create Account') + '</button>' +
            '</form>' +
            '<p style="text-align:center;margin-top:1rem;font-size:0.9rem;">' + (mode==='login'?"New user? ":'Have account? ') + '<a href="#" id="authToggle" style="color:#2563eb;font-weight:600;">' + (mode==='login'?'Sign Up':'Sign In') + '</a></p>' +
            '</div>';
        document.body.appendChild(d);
        
        document.getElementById('authClose').onclick = function() { d.remove(); };
        d.onclick = function(e) { if (e.target === d) d.remove(); };
        document.getElementById('authToggle').onclick = function(e) { e.preventDefault(); d.remove(); AuthModal.show(mode==='login'?'register':'login'); };
        document.getElementById('authForm').onsubmit = function(e) {
            e.preventDefault();
            var email = document.getElementById('authEmail').value.trim();
            var password = document.getElementById('authPassword').value;
            if (!email || !password) { showToast('Fill all fields', 'error'); return; }
            
            var result;
            if (mode === 'login') {
                result = API.login(email, password);
            } else {
                var name = document.getElementById('authName').value.trim();
                if (!name) { showToast('Enter your name', 'error'); return; }
                result = API.register({ name: name, email: email, password: password });
            }
            
            if (result.success) {
                AppState.token = 'token_' + Date.now();
                AppState.currentUser = result.user;
                saveState();
                d.remove();
                refreshAllUI();
                showToast('Welcome, ' + result.user.name + '!', 'success');
                navigateTo('home');
            } else {
                showToast(result.msg || 'Failed', 'error');
            }
        };
    }
};

// ============================================
// NOTIFICATIONS
// ============================================
var NotificationPanel = {
    show: function() {
        var ex = document.getElementById('notifPanel');
        if (ex) { ex.remove(); return; }
        var d = document.createElement('div');
        d.id = 'notifPanel';
        d.style.cssText = 'position:fixed;top:70px;right:10px;width:320px;max-width:90vw;max-height:450px;background:white;border-radius:16px;box-shadow:0 10px 40px rgba(0,0,0,0.2);z-index:10001;overflow:hidden;';
        var h = '<div style="display:flex;justify-content:space-between;padding:14px 18px;border-bottom:1px solid #e5e7eb;"><strong>Notifications</strong><button id="markAllRead" style="border:none;background:none;color:#2563eb;font-size:0.8rem;cursor:pointer;">Mark all read</button></div><div style="max-height:370px;overflow-y:auto;">';
        AppState.notifications.forEach(function(n) {
            h += '<div style="padding:12px 18px;border-bottom:1px solid #f3f4f6;cursor:pointer;' + (n.unread ? 'background:#eff6ff;' : '') + '" onclick="NotificationPanel.read(' + n.id + ')"><strong>' + n.title + '</strong><p style="margin:4px 0;font-size:0.8rem;color:#6b7280;">' + n.msg + '</p><small style="color:#9ca3af;">' + n.time + '</small></div>';
        });
        h += '</div>';
        d.innerHTML = h;
        document.body.appendChild(d);
        document.getElementById('markAllRead').onclick = function() {
            AppState.notifications.forEach(function(n) { n.unread = false; });
            d.remove();
            NotificationPanel.updateBadge();
        };
        setTimeout(function() {
            document.addEventListener('click', function close(e) {
                if (!d.contains(e.target) && e.target.id !== 'notificationBtn') { d.remove(); document.removeEventListener('click', close); }
            });
        }, 100);
    },
    read: function(id) {
        var n = AppState.notifications.find(function(x) { return x.id === id; });
        if (n) n.unread = false;
        var p = document.getElementById('notifPanel');
        if (p) p.remove();
        this.updateBadge();
    },
    updateBadge: function() {
        var b = document.querySelector('.notification-badge');
        if (b) {
            var c = AppState.unreadCount;
            b.textContent = c;
            b.style.display = c > 0 ? 'flex' : 'none';
        }
    }
};

// ============================================
// REFRESH UI
// ============================================
function refreshAllUI() {
    var li = AppState.isLoggedIn;
    var u = AppState.currentUser || { name: 'Guest', email: '' };
    
    // Sidebar
    var si = document.querySelector('.side-menu-header img');
    var sn = document.querySelector('.side-menu-header h3');
    var se = document.querySelector('.side-menu-header p');
    if (si) si.src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(u.name) + '&size=60&background=' + (li ? '7c3aed' : '9ca3af') + '&color=fff';
    if (sn) sn.textContent = li ? u.name : 'Guest User';
    if (se) se.textContent = li ? u.email : 'Sign in to explore';
    
    // Header
    var ha = document.querySelector('.profile-avatar');
    if (ha) ha.src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(u.name) + '&background=' + (li ? '2563eb' : '9ca3af') + '&color=fff';
    
    // Login/Logout buttons
    var lb = document.getElementById('sideLoginBtn');
    var ob = document.getElementById('sideLogoutBtn');
    if (lb) lb.style.display = li ? 'none' : 'flex';
    if (ob) ob.style.display = li ? 'flex' : 'none';
    
    // Profile page
    var pi = document.querySelector('#profile .profile-photo');
    var pn = document.querySelector('#profile .profile-info h2');
    var pe = document.querySelector('#profile .profile-email');
    if (pi) pi.src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(u.name) + '&size=100&background=' + (li ? '7c3aed' : '9ca3af') + '&color=fff';
    if (pn) pn.textContent = li ? u.name : 'Guest User';
    if (pe) pe.innerHTML = '<i class="far fa-envelope"></i> ' + (li ? u.email : 'Sign in to view');
    
    NotificationPanel.updateBadge();
}

// ============================================
// NAVIGATION
// ============================================
function navigateTo(pageId) {
    if (!pageId) return;
    document.querySelectorAll('.page').forEach(function(p) { p.classList.remove('active'); });
    var t = document.getElementById(pageId);
    if (!t) return;
    
    t.classList.add('active');
    AppState.currentPage = pageId;
    
    document.querySelectorAll('.bottom-nav-item, .nav-link').forEach(function(item) {
        item.classList.remove('active');
        if (item.dataset.page === pageId) item.classList.add('active');
    });
    
    // Load page data
    if (pageId === 'home') loadHomePage();
    if (pageId === 'hotels') loadHotelsPage();
    if (pageId === 'itineraries') loadItinerariesPage();
    if (pageId === 'budget') loadBudgetPage();
    if (pageId === 'weather') loadWeatherPage();
    if (pageId === 'reviews') loadReviewsPage();
    if (pageId === 'profile') refreshAllUI();
    if (pageId === 'ai-concierge') { setTimeout(function() { AIPage.load(); }, 200); }
    if (pageId === 'map') { setTimeout(function() { MapPage.load(); }, 300); }
    
    // Close menu
    var sm = document.getElementById('sideMenu');
    var ol = document.querySelector('.menu-overlay');
    if (sm) sm.classList.remove('open');
    if (ol) ol.style.display = 'none';
    document.body.style.overflow = '';
    window.scrollTo(0, 0);
}

// ============================================
// HOME PAGE
// ============================================
function loadHomePage() {
    showLoading(true);
    
    // Stats
    var s = API.stats();
    var sn = document.querySelectorAll('.stat-number');
    if (sn[0]) sn[0].textContent = s.destinations.toLocaleString();
    if (sn[1]) sn[1].textContent = s.states;
    
    // Destinations
    var dests = API.destinations({ category: AppState.filters.category, search: AppState.filters.search });
    
    if (AppState.showingCategories) {
        renderCategoriesOverview(dests);
    } else if (AppState.showingAll || AppState.filters.category !== 'all' || AppState.filters.search) {
        renderDestinationCards(dests);
    } else {
        renderDestinationCards(getPopularDests(dests, 8));
    }
    
    updateBackButton();
    updateSectionTitle(dests.length);
    showLoading(false);
}

function getPopularDests(dests, count) {
    // Fixed 8 popular destinations in exact order (no shuffling)
    var pinned = [
        'Kedarnath', 
        'Srinagar', 
        'Manali', 
        'Lotus Temple', 
        'Goa', 
        'Jaisalmer', 
        'Golden Temple', 
        'Taj Mahal'
    ];
    
    var result = [];
    
    // Find each pinned destination
    pinned.forEach(function(n) {
        // Try exact match first
        var f = dests.find(function(d) { 
            return d.name.toLowerCase() === n.toLowerCase(); 
        });
        
        // If not found, try partial match
        if (!f) {
            f = dests.find(function(d) { 
                return d.name.toLowerCase().indexOf(n.toLowerCase()) !== -1; 
            });
        }
        
        // Add if found and not already in results
        if (f && !result.some(function(r) { return r._id === f._id; })) {
            result.push(f);
        }
    });
    
    // If we have less than 'count', fill from top rated
    if (result.length < count) {
        var ids = result.map(function(d) { return d._id; });
        var remaining = dests.filter(function(d) { 
            return ids.indexOf(d._id) === -1; 
        }).sort(function(a, b) { 
            return (b.rating?.average || 0) - (a.rating?.average || 0); 
        });
        
        for (var i = 0; i < remaining.length && result.length < count; i++) {
            result.push(remaining[i]);
        }
    }
    
    // Return exact number without shuffling
    return result.slice(0, count);
}

function renderDestinationCards(dests) {
    var grid = document.querySelector('.destinations-grid');
    if (!grid) return;
    if (!dests.length) { grid.innerHTML = '<p style="text-align:center;padding:40px;grid-column:1/-1;">No destinations found</p>'; return; }
    
    grid.innerHTML = dests.map(function(d) {
        var img = d.coverImage || 'https://images.pexels.com/photos/7359288/pexels-photo-7359288.jpeg';
        var r = d.rating?.average?.toFixed(1) || '4.5';
        var p = d.price?.average?.perDay || 2000;
        var tags = (d.tags || []).slice(0, 2).map(function(t) { return '<span>' + t + '</span>'; }).join('');
        var fav = AppState.savedDestinations.indexOf(d._id) !== -1;
        
        return '<div class="destination-card" onclick="showDestDetail(\'' + d._id + '\')">' +
            '<div class="card-image"><img src="' + img + '" alt="' + d.name + '" onerror="this.src=\'https://images.pexels.com/photos/7359288/pexels-photo-7359288.jpeg\'">' +
            (d.isFeatured ? '<span class="card-badge">Featured</span>' : '') +
            '<button class="wishlist-btn" onclick="event.stopPropagation();toggleWishlist(\'' + d._id + '\')"><i class="' + (fav ? 'fas' : 'far') + ' fa-heart"></i></button></div>' +
            '<div class="card-content"><h3>' + d.name + '</h3><p class="card-location"><i class="fas fa-map-pin"></i> ' + d.state + '</p>' +
            '<div class="card-tags">' + tags + '</div>' +
            '<div class="card-footer"><span class="rating"><i class="fas fa-star"></i> ' + r + '</span><span class="price">From ' + formatCurrency(p) + '</span></div></div></div>';
    }).join('');
}

function renderCategoriesOverview() {
    var grid = document.querySelector('.destinations-grid');
    if (!grid) return;
    var counts = {};
    CATEGORY_INFO.forEach(function(c) {
        counts[c.id] = AppState.allDestinations.filter(function(d) { return d.category === c.id; }).length;
    });
    grid.innerHTML = CATEGORY_INFO.map(function(c) {
        return '<div class="destination-card" style="border-left:4px solid ' + c.color + ';cursor:pointer;" onclick="selectCategory(\'' + c.id + '\')">' +
            '<div class="card-content" style="text-align:center;padding:1.5rem;">' +
            '<div style="font-size:2rem;color:' + c.color + ';"><i class="fas ' + c.icon + '"></i></div>' +
            '<h3>' + c.name + '</h3><p style="color:#6b7280;font-size:0.8rem;">' + c.desc + '</p>' +
            '<span style="background:' + c.color + '20;color:' + c.color + ';padding:4px 12px;border-radius:20px;font-size:0.8rem;font-weight:600;">' + counts[c.id] + ' places</span></div></div>';
    }).join('');
}

function selectCategory(catId) {
    AppState.showingCategories = false;
    AppState.showingAll = true;
    AppState.filters.category = catId;
    AppState.filters.search = '';
    var si = document.getElementById('searchInput');
    if (si) si.value = '';
    document.querySelectorAll('.category-chip').forEach(function(c) { c.classList.remove('active'); });
    var chip = document.querySelector('.category-chip[data-category="' + catId + '"]');
    if (chip) chip.classList.add('active');
    loadHomePage();
}

function showDestDetail(id) {
    var d = API.destination(id);
    if (d) alert(d.name + ', ' + d.state + '\n\n' + (d.description || '') + '\n\n⭐ ' + (d.rating?.average||4.5).toFixed(1) + '\n💰 ' + formatCurrency(d.price?.average?.perDay||2000) + '/day');
}

function toggleWishlist(id) {
    if (!AppState.isLoggedIn) { AuthModal.show('login'); return; }
    var r = API.toggleWishlist(id);
    showToast(r.saved ? 'Added!' : 'Removed', 'success');
    loadHomePage();
}

function updateSectionTitle(count) {
    var t = document.querySelector('.featured-section .section-header h2');
    if (!t) return;
    if (AppState.showingCategories) t.innerHTML = 'Browse Categories';
    else if (AppState.filters.category !== 'all') t.innerHTML = AppState.filters.category.charAt(0).toUpperCase() + AppState.filters.category.slice(1) + ' <small>(' + count + ')</small>';
    else if (AppState.showingAll) t.innerHTML = 'All Destinations <small>(' + count + ')</small>';
    else t.innerHTML = '✨ Popular Destinations <small>(8)</small>';
}

function updateBackButton() {
    var ex = document.getElementById('homeBackBtn');
    if (ex) ex.remove();
    if (!AppState.showingAll && !AppState.showingCategories && AppState.filters.category === 'all' && !AppState.filters.search) return;
    
    var btn = document.createElement('button');
    btn.id = 'homeBackBtn';
    btn.innerHTML = '<i class="fas fa-arrow-left"></i> Back';
    btn.style.cssText = 'padding:8px 16px;background:white;border:2px solid #e5e7eb;border-radius:25px;font-weight:600;cursor:pointer;margin-bottom:1rem;display:inline-flex;align-items:center;gap:6px;';
    btn.onclick = function() {
        AppState.showingAll = false;
        AppState.showingCategories = false;
        AppState.filters.category = 'all';
        AppState.filters.search = '';
        var si = document.getElementById('searchInput');
        if (si) si.value = '';
        document.querySelectorAll('.category-chip').forEach(function(c) { c.classList.remove('active'); });
        var ac = document.querySelector('.category-chip[data-category="all"]');
        if (ac) ac.classList.add('active');
        loadHomePage();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };
    var fs = document.querySelector('.featured-section');
    if (fs && fs.parentNode) fs.parentNode.insertBefore(btn, fs);
}

// ============================================
// HOTELS PAGE
// ============================================
function loadHotelsPage() {
    var hotels = API.hotels();
    var list = document.querySelector('.hotel-list');
    if (!list) return;
    
    // Apply filters
    if (AppState.hotelFilter === 'budget') hotels = hotels.filter(function(h) { return (h.roomTypes?.[0]?.price?.base || 0) < 3000; });
    if (AppState.hotelFilter === 'mid') hotels = hotels.filter(function(h) { var p = h.roomTypes?.[0]?.price?.base || 0; return p >= 3000 && p <= 10000; });
    if (AppState.hotelFilter === 'luxury') hotels = hotels.filter(function(h) { return (h.roomTypes?.[0]?.price?.base || 0) > 10000; });
    if (AppState.hotelFilter === '5star') hotels = hotels.filter(function(h) { return h.starRating >= 5; });
    
    if (AppState.hotelSearch) {
        var q = AppState.hotelSearch.toLowerCase();
        hotels = hotels.filter(function(h) { return h.name.toLowerCase().indexOf(q) !== -1 || (h.location?.city || '').toLowerCase().indexOf(q) !== -1; });
    }
    
    list.innerHTML = hotels.map(function(h) {
        var img = h.images?.[0]?.url || 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg';
        var r = h.rating?.average?.toFixed(1) || '4.5';
        var p = h.roomTypes?.[0]?.price?.base || 5000;
        var stars = ''; for (var i = 0; i < (h.starRating || 3); i++) stars += '⭐';
        var am = (h.amenities || []).slice(0, 3).map(function(a) { return '<span><i class="fas fa-check-circle"></i> ' + a + '</span>'; }).join('');
        var badge = h.starRating >= 5 ? '<span class="hotel-badge">Luxury</span>' : h.starRating >= 4 ? '<span class="hotel-badge" style="background:#10b981;">Premium</span>' : '<span class="hotel-badge" style="background:#f59e0b;">Budget</span>';
        
        return '<div class="hotel-card"><div class="hotel-image"><img src="' + img + '" alt="' + h.name + '">' + badge + '</div>' +
            '<div class="hotel-content"><div class="hotel-header"><h3>' + h.name + '</h3><div class="hotel-rating"><i class="fas fa-star"></i><span>' + r + '</span></div></div>' +
            '<p class="hotel-location"><i class="fas fa-map-pin"></i> ' + (h.location?.city || '') + ', ' + (h.location?.state || '') + '</p>' +
            '<p style="font-size:0.7rem;color:#6b7280;">' + stars + '</p>' +
            '<div class="hotel-amenities">' + am + '</div>' +
            '<div class="hotel-footer"><div class="hotel-price"><span class="price-amount">' + formatCurrency(p) + '</span><span class="price-night">/ night</span></div>' +
            '<button class="book-btn" onclick="bookHotel(\'' + h._id + '\')">Book Now</button></div></div></div>';
    }).join('');
}

function bookHotel(id) {
    if (!AppState.isLoggedIn) { AuthModal.show('login'); return; }
    showToast('Booking Coming soon');
}

// ============================================
// ITINERARIES PAGE
// ============================================
function loadItinerariesPage() {
    var list = document.querySelector('#itineraries .itinerary-list');
    if (!list) return;
    
    var trips = [
        { id: 1, name: 'Golden Triangle', route: 'Delhi → Agra → Jaipur', days: 5, date: 'Mar 15-20, 2026', progress: 60, img: 'lotus1.jpg', status: 'upcoming' },
        { id: 2, name: 'Kerala Backwaters', route: 'Kochi → Munnar → Alleppey', days: 7, date: 'Apr 10-17, 2026', progress: 30, img: 'kochi.avif', status: 'upcoming' },
        { id: 3, name: 'Himalayan Adventure', route: 'Shimla → Manali → Leh', days: 10, date: 'May 1-10, 2026', progress: 10, img: 'manali.webp', status: 'saved' },
        { id: 4, name: 'Rajasthan Royal', route: 'Jaipur → Jodhpur → Udaipur', days: 6, date: 'Feb 20-26, 2026', progress: 100, img: 'jaisalmer.webp', status: 'past' }
    ];
    
    if (AppState.itineraryTab !== 'all') {
        trips = trips.filter(function(t) { return t.status === AppState.itineraryTab; });
    }
    
    list.innerHTML = trips.map(function(t) {
        var st = t.progress >= 100 ? 'Completed ✅' : t.progress + '% planned';
        return '<div class="itinerary-card"><div class="itinerary-image"><img src="' + t.img + '" alt="' + t.name + '"><span class="trip-duration">' + t.days + ' Days</span></div>' +
            '<div class="itinerary-content"><h3>' + t.name + '</h3><p class="trip-destinations">' + t.route + '</p>' +
            '<div class="trip-dates"><i class="far fa-calendar"></i><span>' + t.date + '</span></div>' +
            '<div class="trip-progress"><div class="progress-bar"><div class="progress-fill" style="width:' + t.progress + '%"></div></div><span class="progress-text">' + st + '</span></div>' +
            '<div class="trip-actions"><button class="btn-view" onclick="showToast(\'Details coming soon!\',\'info\')">View</button>' +
            '<button class="btn-share" onclick="showToast(\'Shared!\',\'success\')"><i class="fas fa-share"></i></button></div></div></div>';
    }).join('');
}

// ============================================
// BUDGET PAGE
// ============================================
function loadBudgetPage() {
    var expenses = JSON.parse(localStorage.getItem('aura_budget') || '[]');
    if (!expenses.length) {
        expenses = [
            { id: 1, name: 'Train Tickets', cat: 'transport', amt: 2400, date: '2026-03-15' },
            { id: 2, name: 'Hotel (3 nights)', cat: 'accommodation', amt: 9800, date: '2026-03-12' },
            { id: 3, name: 'Food Budget', cat: 'food', amt: 4200, date: '2026-03-10' },
            { id: 4, name: 'Activities', cat: 'activities', amt: 2300, date: '2026-03-14' }
        ];
        localStorage.setItem('aura_budget', JSON.stringify(expenses));
    }
    
    // Update summary
    var total = expenses.reduce(function(s, e) { return s + e.amt; }, 0);
    var cats = { transport: 0, accommodation: 0, food: 0, activities: 0 };
    expenses.forEach(function(e) { if (cats[e.cat] !== undefined) cats[e.cat] += e.amt; });
    
    var te = document.querySelector('.budget-amount');
    var pp = document.querySelector('.budget-per-person');
    if (te) te.textContent = formatCurrency(total);
    if (pp) pp.textContent = formatCurrency(Math.round(total / 3)) + ' / person';
    
    var bi = document.querySelectorAll('.breakdown-amount');
    if (bi[0]) bi[0].textContent = formatCurrency(cats.transport);
    if (bi[1]) bi[1].textContent = formatCurrency(cats.accommodation);
    if (bi[2]) bi[2].textContent = formatCurrency(cats.food);
    if (bi[3]) bi[3].textContent = formatCurrency(cats.activities);
    
    // Render list
    var list = document.querySelector('.expense-list');
    if (list) {
        var icons = { transport: 'fa-train', accommodation: 'fa-hotel', food: 'fa-utensils', activities: 'fa-ticket' };
        list.innerHTML = '<h3>Recent Expenses</h3>' + expenses.slice(-6).reverse().map(function(e) {
            return '<div class="expense-item"><div class="expense-icon ' + e.cat + '"><i class="fas ' + (icons[e.cat] || 'fa-receipt') + '"></i></div>' +
                '<div class="expense-details"><span class="expense-name">' + e.name + '</span><span class="expense-date">' + e.date + '</span></div>' +
                '<span class="expense-amount">-₹' + e.amt.toLocaleString('en-IN') + '</span>' +
                '<button style="background:none;border:none;color:#ef4444;cursor:pointer;" onclick="deleteExpense(' + e.id + ')"><i class="fas fa-trash"></i></button></div>';
        }).join('');
    }
}

function addExpense() {
    var name = document.getElementById('expenseName')?.value.trim();
    var amt = parseInt(document.getElementById('expenseAmount')?.value);
    var cat = document.getElementById('expenseCategory')?.value;
    var date = document.getElementById('expenseDate')?.value;
    
    if (!name || !amt || !cat) { showToast('Fill all fields', 'error'); return; }
    
    var expenses = JSON.parse(localStorage.getItem('aura_budget') || '[]');
    expenses.push({ id: Date.now(), name: name, cat: cat, amt: amt, date: date || new Date().toISOString().split('T')[0] });
    localStorage.setItem('aura_budget', JSON.stringify(expenses));
    
    document.getElementById('expenseName').value = '';
    document.getElementById('expenseAmount').value = '';
    document.getElementById('expenseCategory').value = '';
    document.getElementById('expenseDate').value = '';
    
    loadBudgetPage();
    showToast('Expense added!', 'success');
}

function deleteExpense(id) {
    var expenses = JSON.parse(localStorage.getItem('aura_budget') || '[]');
    expenses = expenses.filter(function(e) { return e.id !== id; });
    localStorage.setItem('aura_budget', JSON.stringify(expenses));
    loadBudgetPage();
    showToast('Deleted', 'info');
}

// ============================================
// WEATHER PAGE
// ============================================
function loadWeatherPage() {
    var input = document.getElementById('weatherCityInput');
    if (input && !input.dataset.bound) {
        input.dataset.bound = 'true';
        input.onkeydown = function(e) {
            if (e.key === 'Enter') {
                searchWeather(input.value);
            }
        };
    }
}

function searchWeather(city) {
    if (!city || !city.trim()) { showToast('Enter a city name', 'error'); return; }
    var w = API.weather(city.trim());
    
    var loc = document.querySelector('.weather-location h2');
    var temp = document.querySelector('.temp-value');
    var icon = document.querySelector('.weather-icon-large i');
    var dets = document.querySelectorAll('.weather-detail strong');
    
    if (loc) loc.textContent = city.trim().charAt(0).toUpperCase() + city.trim().slice(1);
    if (temp) temp.textContent = w.temp;
    if (icon) { icon.className = 'fas ' + w.icon; }
    if (dets[0]) dets[0].textContent = w.humidity + '%';
    if (dets[1]) dets[1].textContent = w.wind + ' km/h';
    if (dets[2]) dets[2].textContent = '10 km';
    if (dets[3]) dets[3].textContent = w.feels + '°C';
    
    showToast('Weather updated for ' + city, 'success');
}

// ============================================
// REVIEWS PAGE
// ============================================
function loadReviewsPage() {
    // Reviews are static in HTML, filters just show/hide
    var filterBtns = document.querySelectorAll('.review-filters .filter-btn');
    filterBtns.forEach(function(btn) {
        if (!btn.dataset.bound) {
            btn.dataset.bound = 'true';
            btn.onclick = function() {
                filterBtns.forEach(function(b) { b.classList.remove('active'); });
                this.classList.add('active');
                AppState.reviewFilter = this.textContent.trim();
            };
        }
    });
}

// ============================================
// MAP PAGE - FINAL PERFECT VERSION
// Working Nav Buttons + Clean UI
// ============================================
var MapPage = {
    map: null,
    ready: false,
    userLocation: null,
    userMarker: null,
    routeLine: null,
    destMarker: null,
    currentDest: null,
    satelliteLayer: null,
    streetLayer: null,
    labelsLayer: null,

    init: function() {
        if (this.ready) return;
        var div = document.getElementById('fullMapContainer');
        if (!div || typeof L === 'undefined') {
            if (div) setTimeout(function() { MapPage.init(); }, 300);
            return;
        }

        div.innerHTML = '';
        div.style.height = (window.innerHeight - 200) + 'px';
        div.style.position = 'relative';
        div.style.borderRadius = '0';
        div.style.overflow = 'hidden';
        div.style.margin = '0 -1.25rem';
        div.style.width = 'calc(100% + 2.5rem)';

        // Create map
        this.map = L.map('fullMapContainer', {
            center: [20.5937, 78.9629],
            zoom: 5,
            zoomControl: false,
            dragging: true,
            scrollWheelZoom: true,
            doubleClickZoom: true,
            touchZoom: true,
            bounceAtZoomLimits: true,
            inertia: true,
            inertiaDeceleration: 3000,
            inertiaMaxSpeed: 1500,
            keyboard: true,
            keyboardPanDelta: 80
        });

        // SATELLITE
        this.satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            maxZoom: 20, minZoom: 3
        }).addTo(this.map);

        // LABELS
        this.labelsLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}{r}.png', {
            maxZoom: 20, minZoom: 3, opacity: 0.9
        }).addTo(this.map);

        // STREET (hidden)
        this.streetLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
            maxZoom: 20, minZoom: 3
        });

        this.ready = true;
        var self = this;
        setTimeout(function() { self.map.invalidateSize(); }, 300);

        this.getUserLocation();
        this.addAllControls();
        this.setupSearch();

        window.addEventListener('resize', function() {
            if (self.map) self.map.invalidateSize();
        });
    },

    // ========== USER LOCATION ==========
    getUserLocation: function() {
        var self = this;
        if (!navigator.geolocation) return;

        navigator.geolocation.getCurrentPosition(
            function(pos) {
                self.userLocation = {
                    lat: pos.coords.latitude,
                    lng: pos.coords.longitude
                };

                if (self.userMarker) self.map.removeLayer(self.userMarker);

                var userIcon = L.divIcon({
                    className: 'gps-dot',
                    html: '<div style="width:16px;height:16px;background:#4285F4;border:3px solid white;border-radius:50%;box-shadow:0 0 0 8px rgba(66,133,244,0.2);"></div>',
                    iconSize: [16, 16],
                    iconAnchor: [8, 8]
                });

                self.userMarker = L.marker([pos.coords.latitude, pos.coords.longitude], {
                    icon: userIcon, zIndexOffset: 1000
                }).addTo(self.map);
            },
            function() {},
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
        );
    },

    // ========== SEARCH ==========
    searchDestination: function(query) {
        var self = this;
        if (!query || query.length < 2) {
            showToast('Enter a destination name', 'error');
            return;
        }

        var q = query.toLowerCase().trim();
        var found = null;

        found = AppState.allDestinations.find(function(d) {
            return d.name.toLowerCase() === q;
        });

        if (!found) {
            found = AppState.allDestinations.find(function(d) {
                return d.name.toLowerCase().indexOf(q) !== -1;
            });
        }

        if (!found) {
            found = AppState.allDestinations.find(function(d) {
                return d.state.toLowerCase().indexOf(q) !== -1;
            });
        }

        if (!found || !found.coordinates?.lat || !found.coordinates?.lng) {
            showToast('Not found. Try: Taj Mahal, Goa, Jaipur', 'error');
            return;
        }

        this.currentDest = found;

        // Clear previous
        if (self.destMarker) self.map.removeLayer(self.destMarker);
        if (self.routeLine) self.map.removeLayer(self.routeLine);
        document.getElementById('mapDestInfo')?.classList.add('hidden');

        // Red destination pin
        var destIcon = L.divIcon({
            className: 'dest-red-pin',
            html: '<div style="position:relative;width:36px;height:45px;">' +
                '<svg width="36" height="45" viewBox="0 0 36 45">' +
                '<path d="M18 0C8.06 0 0 8.06 0 18c0 13.5 18 27 18 27s18-13.5 18-27C36 8.06 27.94 0 18 0z" fill="#EA4335" stroke="white" stroke-width="2"/>' +
                '<circle cx="18" cy="16" r="6" fill="white"/>' +
                '</svg></div>',
            iconSize: [36, 45],
            iconAnchor: [18, 45],
            popupAnchor: [0, -45]
        });

        self.destMarker = L.marker([found.coordinates.lat, found.coordinates.lng], {
            icon: destIcon, zIndexOffset: 999
        }).addTo(self.map);

        // Calculate distance
        var distance = null;
        if (self.userLocation) {
            distance = self.calcDistance(
                self.userLocation.lat, self.userLocation.lng,
                found.coordinates.lat, found.coordinates.lng
            );

            self.routeLine = L.polyline(
                [[self.userLocation.lat, self.userLocation.lng],
                 [found.coordinates.lat, found.coordinates.lng]],
                { color: '#4285F4', weight: 3, opacity: 0.5, dashArray: '10, 8' }
            ).addTo(self.map);

            var bounds = L.latLngBounds(
                [self.userLocation.lat, self.userLocation.lng],
                [found.coordinates.lat, found.coordinates.lng]
            );
            self.map.fitBounds(bounds, { padding: [80, 80], maxZoom: 13, animate: true, duration: 1.5 });
        } else {
            self.map.setView([found.coordinates.lat, found.coordinates.lng], 14, {
                animate: true, duration: 1.5
            });
        }

        self.showInfoCard(found, distance);

        var cb = document.getElementById('mapSearchClear');
        if (cb) cb.style.display = 'flex';
    },

    // ========== INFO CARD ==========
    showInfoCard: function(dest, distance) {
        var card = document.getElementById('mapDestInfo');
        if (!card) return;

        var imgUrl = dest.coverImage || 'https://images.pexels.com/photos/7359288/pexels-photo-7359288.jpeg';
        var rating = dest.rating?.average?.toFixed(1) || '4.5';
        var price = formatCurrency(dest.price?.average?.perDay || 2000);
        var distText = '';
        if (distance !== null) {
            distText = distance < 1 ? Math.round(distance * 1000) + ' m' : distance.toFixed(0) + ' km';
        }

        card.innerHTML = '' +
            '<div style="display:flex;gap:12px;align-items:center;position:relative;">' +
            '<img src="' + imgUrl + '" style="width:70px;height:70px;border-radius:14px;object-fit:cover;flex-shrink:0;" onerror="this.src=\'https://images.pexels.com/photos/7359288/pexels-photo-7359288.jpeg\'">' +
            '<div style="flex:1;min-width:0;">' +
            '<h4 style="margin:0 0 4px;font-size:1rem;font-weight:700;">' + dest.name + '</h4>' +
            '<p style="margin:0 0 6px;font-size:0.8rem;color:#6b7280;">' + dest.state + '</p>' +
            '<div style="display:flex;gap:6px;flex-wrap:wrap;">' +
            '<span style="background:#FFF7ED;color:#EA580C;padding:3px 8px;border-radius:10px;font-size:0.7rem;font-weight:600;">⭐ ' + rating + '</span>' +
            '<span style="background:#EFF6FF;color:#2563EB;padding:3px 8px;border-radius:10px;font-size:0.7rem;font-weight:600;">' + price + '/d</span>' +
            (distText ? '<span style="background:#F0FDF4;color:#16A34A;padding:3px 8px;border-radius:10px;font-size:0.7rem;font-weight:600;">📍 ' + distText + '</span>' : '') +
            '</div></div>' +
            '<button onclick="document.getElementById(\'mapDestInfo\').classList.add(\'hidden\')" style="position:absolute;top:0;right:0;width:24px;height:24px;border-radius:50%;border:none;background:#f3f4f6;cursor:pointer;font-size:0.9rem;color:#6b7280;">×</button>' +
            '</div>';

        card.style.cssText = 'position:absolute;bottom:20px;left:10px;right:10px;background:white;border-radius:16px;padding:14px;box-shadow:0 8px 30px rgba(0,0,0,0.25);z-index:999;max-width:400px;margin:0 auto;';
        card.classList.remove('hidden');
    },

    // ========== DISTANCE ==========
    calcDistance: function(lat1, lng1, lat2, lng2) {
        var R = 6371;
        var dLat = (lat2 - lat1) * Math.PI / 180;
        var dLng = (lng2 - lng1) * Math.PI / 180;
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                Math.sin(dLng / 2) * Math.sin(dLng / 2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    },

    // ========== ALL CONTROLS ==========
    addAllControls: function() {
        var self = this;
        var div = document.getElementById('fullMapContainer');
        if (!div) return;

        // === VIEW TOGGLE ===
        var toggle = document.createElement('div');
        toggle.style.cssText = 'position:absolute;top:12px;left:50%;transform:translateX(-50%);z-index:1000;display:flex;background:white;border-radius:25px;padding:3px;box-shadow:0 4px 15px rgba(0,0,0,0.15);';
        toggle.innerHTML =
            '<button id="satBtn" style="padding:8px 16px;background:#1a73e8;color:white;border:none;border-radius:22px;font-size:0.75rem;font-weight:600;cursor:pointer;">🛰️ Satellite</button>' +
            '<button id="streetBtn" style="padding:8px 16px;background:transparent;color:#5f6368;border:none;border-radius:22px;font-size:0.75rem;font-weight:600;cursor:pointer;">🗺️ Map</button>';
        div.appendChild(toggle);

        document.getElementById('satBtn').onclick = function() {
            self.map.removeLayer(self.streetLayer);
            if (!self.map.hasLayer(self.satelliteLayer)) self.map.addLayer(self.satelliteLayer);
            if (!self.map.hasLayer(self.labelsLayer)) self.map.addLayer(self.labelsLayer);
            this.style.background = '#1a73e8'; this.style.color = 'white';
            document.getElementById('streetBtn').style.background = 'transparent';
            document.getElementById('streetBtn').style.color = '#5f6368';
        };

        document.getElementById('streetBtn').onclick = function() {
            self.map.removeLayer(self.satelliteLayer);
            self.map.removeLayer(self.labelsLayer);
            if (!self.map.hasLayer(self.streetLayer)) self.map.addLayer(self.streetLayer);
            this.style.background = '#1a73e8'; this.style.color = 'white';
            document.getElementById('satBtn').style.background = 'transparent';
            document.getElementById('satBtn').style.color = '#5f6368';
        };

        // === ZOOM BUTTONS ===
        var zoomDiv = document.createElement('div');
        zoomDiv.style.cssText = 'position:absolute;top:80px;right:12px;z-index:1000;display:flex;flex-direction:column;background:white;border-radius:8px;box-shadow:0 2px 12px rgba(0,0,0,0.15);overflow:hidden;';
        zoomDiv.innerHTML =
            '<button id="zoomIn" style="width:40px;height:40px;background:white;border:none;border-bottom:1px solid #e8eaed;font-size:1.3rem;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#5f6368;">+</button>' +
            '<button id="zoomOut" style="width:40px;height:40px;background:white;border:none;font-size:1.3rem;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#5f6368;">−</button>' +
            '<button id="locateMe" style="width:40px;height:40px;background:white;border:none;border-top:1px solid #e8eaed;font-size:1rem;cursor:pointer;display:flex;align-items:center;justify-content:center;">📍</button>';
        div.appendChild(zoomDiv);

        document.getElementById('zoomIn').onclick = function() { self.map.zoomIn(); };
        document.getElementById('zoomOut').onclick = function() { self.map.zoomOut(); };
        document.getElementById('locateMe').onclick = function() {
            if (self.userLocation) {
                self.map.setView([self.userLocation.lat, self.userLocation.lng], 16, { animate: true, duration: 1 });
            } else {
                self.getUserLocation();
            }
        };

        // === NAVIGATION PAD (D-PAD) ===
        var navPad = document.createElement('div');
        navPad.style.cssText = 'position:absolute;bottom:30px;right:12px;z-index:1000;display:grid;grid-template-columns:44px 44px 44px;grid-template-rows:44px 44px 44px;gap:3px;';
        navPad.innerHTML =
            '<div></div>' +
            '<button id="navUp" style="width:44px;height:44px;background:white;border:1px solid #dadce0;border-radius:8px;cursor:pointer;font-size:1.1rem;display:flex;align-items:center;justify-content:center;color:#5f6368;box-shadow:0 2px 6px rgba(0,0,0,0.1);user-select:none;">▲</button>' +
            '<div></div>' +
            '<button id="navLeft" style="width:44px;height:44px;background:white;border:1px solid #dadce0;border-radius:8px;cursor:pointer;font-size:1.1rem;display:flex;align-items:center;justify-content:center;color:#5f6368;box-shadow:0 2px 6px rgba(0,0,0,0.1);user-select:none;">◀</button>' +
            '<button id="navCenter" style="width:44px;height:44px;background:white;border:2px solid #1a73e8;border-radius:8px;cursor:pointer;font-size:0.8rem;display:flex;align-items:center;justify-content:center;color:#1a73e8;font-weight:700;box-shadow:0 2px 6px rgba(0,0,0,0.1);user-select:none;">⊙</button>' +
            '<button id="navRight" style="width:44px;height:44px;background:white;border:1px solid #dadce0;border-radius:8px;cursor:pointer;font-size:1.1rem;display:flex;align-items:center;justify-content:center;color:#5f6368;box-shadow:0 2px 6px rgba(0,0,0,0.1);user-select:none;">▶</button>' +
            '<div></div>' +
            '<button id="navDown" style="width:44px;height:44px;background:white;border:1px solid #dadce0;border-radius:8px;cursor:pointer;font-size:1.1rem;display:flex;align-items:center;justify-content:center;color:#5f6368;box-shadow:0 2px 6px rgba(0,0,0,0.1);user-select:none;">▼</button>' +
            '<div></div>';
        div.appendChild(navPad);

        // NAV BUTTON HANDLERS
        var panAmt = 120;
        document.getElementById('navUp').onclick = function() { self.map.panBy([0, -panAmt], { animate: true, duration: 0.25 }); };
        document.getElementById('navDown').onclick = function() { self.map.panBy([0, panAmt], { animate: true, duration: 0.25 }); };
        document.getElementById('navLeft').onclick = function() { self.map.panBy([-panAmt, 0], { animate: true, duration: 0.25 }); };
        document.getElementById('navRight').onclick = function() { self.map.panBy([panAmt, 0], { animate: true, duration: 0.25 }); };
        document.getElementById('navCenter').onclick = function() {
            if (self.userLocation) {
                self.map.setView([self.userLocation.lat, self.userLocation.lng], 16, { animate: true, duration: 1 });
            } else {
                self.getUserLocation();
            }
        };
    },

    // ========== SEARCH SETUP ==========
    setupSearch: function() {
        var self = this;
        var input = document.getElementById('mapSearchInput');
        var clearBtn = document.getElementById('mapSearchClear');

        if (!input) return;

        input.setAttribute('placeholder', 'Search places...');

        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                self.searchDestination(this.value.trim());
                this.blur();
            }
        });

        if (clearBtn) {
            clearBtn.style.display = 'none';
            clearBtn.onclick = function() {
                input.value = '';
                clearBtn.style.display = 'none';
                if (self.destMarker) { self.map.removeLayer(self.destMarker); self.destMarker = null; }
                if (self.routeLine) { self.map.removeLayer(self.routeLine); self.routeLine = null; }
                self.currentDest = null;
                document.getElementById('mapDestInfo')?.classList.add('hidden');
                self.map.setView([20.5937, 78.9629], 5, { animate: true, duration: 1 });
            };
        }

        input.addEventListener('input', function() {
            if (clearBtn) clearBtn.style.display = this.value.length > 0 ? 'flex' : 'none';
        });
    },

    load: function() {
        this.ready = false;
        if (this.map) { this.map.remove(); this.map = null; }
        this.destMarker = null;
        this.routeLine = null;
        this.userMarker = null;
        this.currentDest = null;
        this.init();
        var self = this;
        setTimeout(function() { if (self.map) self.map.invalidateSize(); }, 500);
    }
};

// ============================================
// AI PAGE
// ============================================
const AIPage = {
    initialized: false,

    init: function() {
        if (this.initialized) return;
        this.initialized = true;
        
        const sendBtn = document.getElementById('sendMessageBtn');
        const input = document.getElementById('chatInput');

        if (sendBtn) {
            const newSendBtn = sendBtn.cloneNode(true);
            sendBtn.parentNode.replaceChild(newSendBtn, sendBtn);
            newSendBtn.addEventListener('click', () => this.handleUserMessage());
        }

        if (input) {
            const newInput = input.cloneNode(true);
            input.parentNode.replaceChild(newInput, input);
            newInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.handleUserMessage();
                }
            });
        }

        document.querySelectorAll('.suggestion-chip').forEach(chip => {
            const newChip = chip.cloneNode(true);
            chip.parentNode.replaceChild(newChip, chip);
            newChip.addEventListener('click', () => {
                const text = newChip.textContent.replace(/"/g, '').trim();
                if (text) this.processMessage(text);
            });
        });

        document.querySelectorAll('.ai-suggestion-btn').forEach(btn => {
            if (!btn.dataset.aiInitialized) {
                btn.dataset.aiInitialized = 'true';
                btn.addEventListener('click', () => {
                    navigateTo('ai-concierge');
                    setTimeout(() => {
                        const text = btn.textContent.replace(/"/g, '').trim();
                        this.processMessage(text);
                    }, 500);
                });
            }
        });
    },

    handleUserMessage: function() {
        const input = document.getElementById('chatInput');
        if (!input) return;
        
        const message = input.value.trim();
        if (message === '') return;
        
        this.processMessage(message);
        input.value = '';
    },

    processMessage: function(message) {
        if (this._lastMessage === message && this._lastMessageTime && Date.now() - this._lastMessageTime < 2000) {
            return;
        }
        this._lastMessage = message;
        this._lastMessageTime = Date.now();
        
        this.addMessage(message, 'user');
        this.showTyping();
        
        setTimeout(() => {
            this.removeTyping();
            const reply = this.generateReply(message);
            this.addMessage(reply, 'ai');
        }, 1000);
    },

    generateReply: function(message) {
        const text = message.toLowerCase();

        if (text.includes('beach') || text.includes('goa')) {
            return `🏖️ <strong>Best Beach Destinations:</strong><br><br>
            • <strong>Goa</strong> - Baga, Calangute, Palolem<br>
            • <strong>Andaman</strong> - Radhanagar Beach<br>
            • <strong>Gokarna</strong> - Om Beach, Kudle Beach<br>
            • <strong>Varkala</strong> - Cliff Beach<br>
            • <strong>Pondicherry</strong> - Promenade Beach<br><br>
            <em>Best time: October to March</em>`;
        }

        if (text.includes('mountain') || text.includes('hill') || text.includes('manali') || text.includes('leh')) {
            return `🏔️ <strong>Top Mountain Destinations:</strong><br><br>
            • <strong>Manali</strong> - Adventure sports, Solang Valley<br>
            • <strong>Leh Ladakh</strong> - Pangong Lake, Monasteries<br>
            • <strong>Shimla</strong> - Mall Road, Colonial charm<br>
            • <strong>Auli</strong> - Skiing destination<br>
            • <strong>Munnar</strong> - Tea gardens, Eravikulam<br><br>
            <em>Best time: April to June</em>`;
        }

        if (text.includes('temple') || text.includes('kedarnath') || text.includes('pilgrimage')) {
            return `🛕 <strong>Famous Temple Destinations:</strong><br><br>
            • <strong>Kedarnath</strong> - Jyotirlinga in Himalayas<br>
            • <strong>Rameswaram</strong> - Char Dham pilgrimage site<br>
            • <strong>Vaishno Devi</strong> - Holy cave shrine<br>
            • <strong>Tirupati</strong> - Richest temple in India<br>
            • <strong>Somnath</strong> - First among 12 Jyotirlingas<br><br>
            <em>Plan your spiritual journey today!</em>`;
        }

        if (text.includes('budget') || text.includes('cheap') || text.includes('affordable')) {
            return `💰 <strong>Budget-Friendly Destinations:</strong><br><br>
            • <strong>Rishikesh</strong> - ₹1,500-2,500/day<br>
            • <strong>Kasol</strong> - ₹1,200-2,000/day<br>
            • <strong>Pushkar</strong> - ₹1,000-2,000/day<br>
            • <strong>Varanasi</strong> - ₹1,500-2,500/day<br>
            • <strong>McLeod Ganj</strong> - ₹1,500-2,000/day<br><br>
            <em>Travel off-season for the best deals!</em>`;
        }

        if (text.includes('jaipur') || text.includes('rajasthan') || text.includes('golden triangle')) {
            return `👑 <strong>Golden Triangle Tour (5 Days):</strong><br><br>
            <strong>Day 1-2: Delhi</strong><br>
            • Red Fort, India Gate, Qutub Minar<br>
            • Lotus Temple, Humayun's Tomb<br><br>
            <strong>Day 3: Agra</strong><br>
            • Taj Mahal at sunrise<br>
            • Agra Fort, Fatehpur Sikri<br><br>
            <strong>Day 4-5: Jaipur</strong><br>
            • Amer Fort, Hawa Mahal<br>
            • City Palace, Jantar Mantar<br><br>
            <em>Budget: ₹15,000-20,000 per person</em>`;
        }

        if (text.includes('hello') || text.includes('hi') || text.includes('hey') || text.includes('help')) {
            const userName = AppState.currentUser ? AppState.currentUser.name.split(' ')[0] : 'there';
            return `👋 Hello <strong>${userName}</strong>! I'm your AI travel assistant.<br><br>
            I can help you with:<br>
            • 🌴 <strong>Beach destinations</strong> - "Best beaches in India"<br>
            • 🏔️ <strong>Mountain getaways</strong> - "Hill stations to visit"<br>
            • 🛕 <strong>Temple tours</strong> - "Famous temples"<br>
            • 💰 <strong>Budget planning</strong> - "Budget trips"<br>
            • 👑 <strong>Itineraries</strong> - "Golden Triangle tour"<br><br>
            What would you like to explore today? ✈️`;
        }

        if (text.includes('kerala') || text.includes('backwaters')) {
            return `🌴 <strong>Kerala - God's Own Country:</strong><br><br>
            <strong>Top Destinations:</strong><br>
            • <strong>Alleppey</strong> - Houseboat cruises<br>
            • <strong>Munnar</strong> - Tea plantations<br>
            • <strong>Kochi</strong> - Chinese fishing nets<br>
            • <strong>Thekkady</strong> - Periyar wildlife<br>
            • <strong>Varkala</strong> - Cliff beaches<br><br>
            <em>Best time: September to March</em>`;
        }

        return `🤖 I can help you plan your perfect India trip! Ask me about:<br><br>
        • "Best beaches in India" 🏖️<br>
        • "Hill stations to visit" 🏔️<br>
        • "Famous temple tours" 🛕<br>
        • "Budget trip ideas" 💰<br>
        • "Golden Triangle itinerary" 👑<br>
        • "Kerala backwaters" 🌴<br><br>
        <em>Just type your question above!</em> ✈️`;
    },

    addMessage: function(text, sender) {
        const container = document.getElementById('chatContainer');
        if (!container) return;

        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${sender}-message`;

        if (sender === 'ai') {
            messageDiv.innerHTML = `
                <div class="message-avatar"><i class="fas fa-robot"></i></div>
                <div class="message-content"><p>${text}</p></div>
            `;
        } else {
            messageDiv.innerHTML = `
                <div class="message-content"><p>${text}</p></div>
            `;
        }

        container.appendChild(messageDiv);
        container.scrollTop = container.scrollHeight;
    },

    showTyping: function() {
        this.removeTyping();
        
        const container = document.getElementById('chatContainer');
        if (!container) return;
        
        const typingDiv = document.createElement('div');
        typingDiv.id = 'typingMessage';
        typingDiv.className = 'chat-message ai-message';
        typingDiv.innerHTML = `
            <div class="message-avatar"><i class="fas fa-robot"></i></div>
            <div class="message-content"><p><em>Typing...</em></p></div>
        `;
        container.appendChild(typingDiv);
        container.scrollTop = container.scrollHeight;
    },

    removeTyping: function() {
        const typing = document.getElementById('typingMessage');
        if (typing) typing.remove();
    },

    load: function() {
        this.initialized = false;
        this.init();
    }
};

// ============================================
// SIDE MENU
// ============================================
function initSideMenu() {
    var mt = document.getElementById('menuToggle'), sm = document.getElementById('sideMenu'), cb = document.getElementById('closeMenu');
    if (!mt || !sm) return;
    var ol = document.querySelector('.menu-overlay');
    if (!ol) { ol = document.createElement('div'); ol.className = 'menu-overlay'; ol.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:999;display:none;'; document.body.appendChild(ol); }
    mt.onclick = function() { sm.classList.add('open'); ol.style.display = 'block'; };
    var close = function() { sm.classList.remove('open'); ol.style.display = 'none'; };
    if (cb) cb.onclick = close;
    ol.onclick = close;
}

// ============================================
// SETUP ALL EVENTS
// ============================================
function setupAllEvents() {
    // Navigation clicks using event delegation
    document.addEventListener('click', function(e) {
        // Bottom nav
        var bn = e.target.closest('.bottom-nav-item');
        if (bn && bn.dataset.page) { e.preventDefault(); navigateTo(bn.dataset.page); return; }
        
        // Side nav
        var nl = e.target.closest('.nav-link');
        if (nl && nl.dataset.page) { e.preventDefault(); navigateTo(nl.dataset.page); return; }
        
        // Back buttons
        if (e.target.closest('.back-btn')) { navigateTo('home'); return; }
        
        // Feature cards
        var fc = e.target.closest('.feature-card');
        if (fc && fc.dataset.page) { e.preventDefault(); navigateTo(fc.dataset.page); return; }
        
        // Category chips
        var cc = e.target.closest('.category-chip');
        if (cc && cc.dataset.category) {
            document.querySelectorAll('.category-chip').forEach(function(c) { c.classList.remove('active'); });
            cc.classList.add('active');
            AppState.filters.category = cc.dataset.category;
            AppState.filters.search = '';
            AppState.showingCategories = false;
            AppState.showingAll = true;
            var si = document.getElementById('searchInput'); if (si) si.value = '';
            loadHomePage();
            return;
        }
        
        // See all / View all
        var sa = e.target.closest('.see-all-link');
        if (sa) {
            e.preventDefault();
            var isCat = sa.closest('.category-section');
            AppState.showingCategories = !!isCat;
            AppState.showingAll = !isCat;
            AppState.filters.category = 'all';
            AppState.filters.search = '';
            document.querySelectorAll('.category-chip').forEach(function(c) { c.classList.remove('active'); });
            var ac = document.querySelector('.category-chip[data-category="all"]');
            if (ac) ac.classList.add('active');
            var si = document.getElementById('searchInput'); if (si) si.value = '';
            loadHomePage();
            return;
        }
        
        // Tab buttons
        var tb = e.target.closest('.tab-btn');
        if (tb) {
            var parent = tb.parentElement;
            if (parent) parent.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
            tb.classList.add('active');
            var tabText = tb.textContent.trim().toLowerCase();
            if (tabText === 'upcoming') AppState.itineraryTab = 'upcoming';
            if (tabText === 'past') AppState.itineraryTab = 'past';
            if (tabText === 'saved') AppState.itineraryTab = 'saved';
            loadItinerariesPage();
            return;
        }
        
        // Hotel filters
        var hf = e.target.closest('.hotel-filters .filter-chip');
        if (hf) {
            var p = hf.parentElement;
            if (p) p.querySelectorAll('.filter-chip').forEach(function(b) { b.classList.remove('active'); });
            hf.classList.add('active');
            var ft = hf.textContent.trim();
            if (ft === 'All') AppState.hotelFilter = 'all';
            else if (ft.indexOf('Under') !== -1) AppState.hotelFilter = 'budget';
            else if (ft.indexOf('₹2,000') !== -1) AppState.hotelFilter = 'mid';
            else if (ft.indexOf('Luxury') !== -1) AppState.hotelFilter = 'luxury';
            else if (ft.indexOf('4★') !== -1) AppState.hotelFilter = '5star';
            loadHotelsPage();
            return;
        }
        
        // FAQ
        var fq = e.target.closest('.faq-question');
        if (fq) { fq.parentElement.classList.toggle('active'); return; }
    });
    
    // Profile button
    document.getElementById('profileBtn')?.addEventListener('click', function() {
        AppState.isLoggedIn ? navigateTo('profile') : AuthModal.show('login');
    });
    
    // Notification
    document.getElementById('notificationBtn')?.addEventListener('click', function(e) {
        e.stopPropagation(); NotificationPanel.show();
    });
    
    // Search input
    var si = document.getElementById('searchInput');
    if (si) {
        si.addEventListener('input', function() {
            var q = this.value.trim();
            if (!q) { AppState.filters.search = ''; AppState.showingAll = false; loadHomePage(); return; }
            if (q.length < 2) return;
            AppState.filters.search = q;
            AppState.showingAll = true;
            loadHomePage();
        });
    }
    
    // AI card
    document.getElementById('aiConciergeCard')?.addEventListener('click', function(e) {
        if (!e.target.closest('input, button')) navigateTo('ai-concierge');
    });
    
    // Hotel search
    var hs = document.querySelector('.hotel-search input[type="text"]');
    if (hs) {
        hs.addEventListener('input', function() {
            AppState.hotelSearch = this.value.trim();
            loadHotelsPage();
        });
    }
    
    // Search hotel button
    document.querySelector('.search-hotel-btn')?.addEventListener('click', function() {
        showToast('Searching...', 'info');
        loadHotelsPage();
    });
    
    // Logout
    var doLogout = function() {
        AppState.token = null; AppState.currentUser = null; AppState.savedDestinations = [];
        saveState();
        refreshAllUI();
        showToast('Logged out', 'success');
        navigateTo('home');
    };
    document.getElementById('sideLoginBtn')?.addEventListener('click', function() { AuthModal.show('login'); });
    document.getElementById('sideLogoutBtn')?.addEventListener('click', doLogout);
    document.querySelector('.logout-btn-large')?.addEventListener('click', doLogout);
    
    // Add expense button
    document.querySelector('.add-expense-btn')?.addEventListener('click', addExpense);
    
    // Generate itinerary
    document.querySelector('#itineraries .generate-btn')?.addEventListener('click', function() {
        showToast('Itinerary generated! 🎉', 'success');
    });
    
    // Write review
    document.getElementById('writeReviewBtn')?.addEventListener('click', function() {
        if (!AppState.isLoggedIn) { AuthModal.show('login'); return; }
        showToast('Review form opening...', 'info');
    });
    
    // New chat
    document.getElementById('newChatBtn')?.addEventListener('click', function() {
        var c = document.getElementById('chatContainer');
        if (c) c.innerHTML = '<div class="chat-message ai-message"><div class="message-avatar"><i class="fas fa-robot"></i></div><div class="message-content"><p>Hello! How can I help you today? ✈️</p></div></div>';
    });
    
    // Locate on map
    document.getElementById('mapPageLocateBtn')?.addEventListener('click', function() {
        if (navigator.geolocation && MapPage.map) {
            navigator.geolocation.getCurrentPosition(function(p) {
                MapPage.map.setView([p.coords.latitude, p.coords.longitude], 10);
            });
        }
    });
}

// ============================================
// MAIN
// ============================================
document.addEventListener('DOMContentLoaded', async function() {
    await waitForDataset();
    console.log('✅ ' + AppState.allDestinations.length + ' destinations loaded');
    
    loadState();
    
    setTimeout(function() {
        document.getElementById('loadingScreen')?.classList.add('hidden');
    }, 500);
    
    initSideMenu();
    setupAllEvents();
    AIPage.init();
    refreshAllUI();
    NotificationPanel.updateBadge();
    loadHomePage();
    
    console.log('✅ Aura Travel Ready!');
    console.log('👤 Demo: himanshu11@gmail.com / 111');
});
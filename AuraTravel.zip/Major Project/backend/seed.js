// ============================================
// SEED DATA FOR AURA TRAVEL
// ============================================
const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI);

// Models (simplified for seed)
const Destination = mongoose.model('Destination', new mongoose.Schema({
    name: String, state: String, category: String, type: String,
    description: String, shortDescription: String,
    coordinates: { lat: Number, lng: Number },
    coverImage: String,
    rating: { average: Number, count: Number },
    bestTimeToVisit: { months: [String], description: String },
    price: { average: { perDay: Number } },
    tags: [String],
    isFeatured: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    statistics: { views: { type: Number, default: 0 } }
}, { timestamps: true }));

const Hotel = mongoose.model('Hotel', new mongoose.Schema({
    name: String,
    destination: { type: mongoose.Schema.Types.ObjectId, ref: 'Destination' },
    location: { address: String, city: String, state: String, coordinates: { lat: Number, lng: Number } },
    category: String,
    starRating: Number,
    description: String,
    amenities: [String],
    roomTypes: [{ name: String, price: { base: Number }, availableRooms: Number }],
    rating: { average: Number, count: Number },
    isActive: { type: Boolean, default: true }
}));

const User = mongoose.model('User', new mongoose.Schema({
    name: String, email: String, password: String, role: String
}));

const bcrypt = require('bcryptjs');

// Sample Destinations
const destinations = [
    {
        name: 'Kedarnath', state: 'Uttarakhand', category: 'temples', type: 'Temple',
        description: 'Sacred Hindu temple dedicated to Lord Shiva in the Himalayas.',
        shortDescription: 'Sacred Himalayan shrine at 3,583m',
        coordinates: { lat: 30.7352, lng: 79.0669 },
        coverImage: 'https://images.pexels.com/photos/7359288/pexels-photo-7359288.jpeg',
        rating: { average: 4.8, count: 1250 },
        bestTimeToVisit: { months: ['May', 'June', 'September', 'October'], description: 'Open May to October' },
        price: { average: { perDay: 2500 } },
        tags: ['Temple', 'Himalayas', 'Pilgrimage'],
        isFeatured: true
    },
    {
        name: 'Taj Mahal', state: 'Uttar Pradesh', category: 'monuments', type: 'Monument',
        description: 'Ivory-white marble mausoleum, one of the Seven Wonders of the World.',
        shortDescription: 'UNESCO World Heritage - Symbol of Love',
        coordinates: { lat: 27.1751, lng: 78.0421 },
        coverImage: 'https://images.pexels.com/photos/1603650/pexels-photo-1603650.jpeg',
        rating: { average: 4.9, count: 3500 },
        bestTimeToVisit: { months: ['October', 'November', 'December', 'January', 'February', 'March'], description: 'Best at sunrise' },
        price: { average: { perDay: 1200 } },
        tags: ['Monument', 'UNESCO', 'Wonder'],
        isFeatured: true
    },
    {
        name: 'Goa Beaches', state: 'Goa', category: 'beaches', type: 'Beach',
        description: 'Beautiful beaches stretching along the Arabian Sea.',
        shortDescription: 'India\'s beach paradise',
        coordinates: { lat: 15.2993, lng: 74.1240 },
        coverImage: 'https://images.pexels.com/photos/237272/pexels-photo-237272.jpeg',
        rating: { average: 4.6, count: 4200 },
        bestTimeToVisit: { months: ['November', 'December', 'January', 'February'], description: 'Perfect beach weather' },
        price: { average: { perDay: 3200 } },
        tags: ['Beach', 'Nightlife', 'Water Sports'],
        isFeatured: true
    },
    {
        name: 'Rameswaram', state: 'Tamil Nadu', category: 'temples', type: 'Temple',
        description: 'One of the Char Dham pilgrimage sites.',
        shortDescription: 'Sacred island temple',
        coordinates: { lat: 9.2886, lng: 79.3132 },
        coverImage: 'https://images.pexels.com/photos/2869334/pexels-photo-2869334.jpeg',
        rating: { average: 4.7, count: 980 },
        bestTimeToVisit: { months: ['October', 'November', 'December', 'January', 'February', 'March', 'April'], description: 'Pleasant year-round' },
        price: { average: { perDay: 1800 } },
        tags: ['Temple', 'Coastal', 'Pilgrimage']
    },
    {
        name: 'Manali', state: 'Himachal Pradesh', category: 'mountains', type: 'Hill Station',
        description: 'High-altitude Himalayan resort town.',
        shortDescription: 'Adventure capital of Himachal',
        coordinates: { lat: 32.2432, lng: 77.1892 },
        coverImage: 'https://images.pexels.com/photos/2422461/pexels-photo-2422461.jpeg',
        rating: { average: 4.6, count: 2100 },
        bestTimeToVisit: { months: ['March', 'April', 'May', 'June', 'September', 'October'], description: 'Summer for adventure' },
        price: { average: { perDay: 3000 } },
        tags: ['Mountains', 'Adventure', 'Snow']
    },
    {
        name: 'Kerala Backwaters', state: 'Kerala', category: 'backwaters', type: 'Backwaters',
        description: 'Network of brackish lagoons and lakes.',
        shortDescription: 'Venice of the East',
        coordinates: { lat: 9.5916, lng: 76.5222 },
        coverImage: 'https://images.pexels.com/photos/962464/pexels-photo-962464.jpeg',
        rating: { average: 4.7, count: 1800 },
        bestTimeToVisit: { months: ['September', 'October', 'November', 'December', 'January', 'February', 'March'], description: 'Post-monsoon' },
        price: { average: { perDay: 3500 } },
        tags: ['Backwaters', 'Houseboat', 'Nature']
    },
    {
        name: 'Jaipur', state: 'Rajasthan', category: 'heritage', type: 'City',
        description: 'The Pink City, capital of Rajasthan.',
        shortDescription: 'The Pink City',
        coordinates: { lat: 26.9124, lng: 75.7873 },
        coverImage: 'https://images.pexels.com/photos/3581368/pexels-photo-3581368.jpeg',
        rating: { average: 4.7, count: 3100 },
        bestTimeToVisit: { months: ['October', 'November', 'December', 'January', 'February', 'March'], description: 'Perfect for sightseeing' },
        price: { average: { perDay: 2800 } },
        tags: ['Heritage', 'Palaces', 'Forts']
    },
    {
        name: 'Varanasi', state: 'Uttar Pradesh', category: 'temples', type: 'City',
        description: 'Spiritual capital of India on the Ganges.',
        shortDescription: 'Spiritual heart of India',
        coordinates: { lat: 25.3176, lng: 83.0068 },
        coverImage: 'https://images.pexels.com/photos/2727120/pexels-photo-2727120.jpeg',
        rating: { average: 4.5, count: 2400 },
        bestTimeToVisit: { months: ['October', 'November', 'December', 'January', 'February', 'March'], description: 'Pleasant weather' },
        price: { average: { perDay: 1800 } },
        tags: ['Temple', 'Spiritual', 'Ganges']
    }
];

const seed = async () => {
    try {
        await Destination.deleteMany();
        await Hotel.deleteMany();
        console.log('🗑️  Old data cleared');
        
        const createdDestinations = await Destination.insertMany(destinations);
        console.log(`✅ ${createdDestinations.length} destinations created`);
        
        // Create hotels
        const goa = createdDestinations.find(d => d.state === 'Goa');
        const agra = createdDestinations.find(d => d.name === 'Taj Mahal');
        const manali = createdDestinations.find(d => d.name === 'Manali');
        
        const hotels = [
            {
                name: 'Taj Fort Aguada', destination: goa._id,
                location: { address: 'Sinquerim, Candolim', city: 'Goa', state: 'Goa', coordinates: { lat: 15.4989, lng: 73.7735 } },
                category: 'luxury', starRating: 5,
                description: 'Luxury beach resort with Arabian Sea views',
                amenities: ['Free WiFi', 'Pool', 'Spa', 'Restaurant', 'Beach Access'],
                roomTypes: [{ name: 'Deluxe Sea View', price: { base: 8500 }, availableRooms: 20 }],
                rating: { average: 4.7, count: 850 }
            },
            {
                name: 'The Oberoi Amarvilas', destination: agra._id,
                location: { address: 'Taj East Gate Road', city: 'Agra', state: 'Uttar Pradesh', coordinates: { lat: 27.1680, lng: 78.0500 } },
                category: 'luxury', starRating: 5,
                description: 'Luxury hotel with Taj Mahal views',
                amenities: ['Free WiFi', 'Pool', 'Spa', 'Fine Dining', 'Taj View'],
                roomTypes: [{ name: 'Premier Room', price: { base: 25000 }, availableRooms: 15 }],
                rating: { average: 4.9, count: 1200 }
            },
            {
                name: 'Himalayan Resort', destination: manali._id,
                location: { address: 'Hadimba Temple Road', city: 'Manali', state: 'Himachal Pradesh', coordinates: { lat: 32.2432, lng: 77.1892 } },
                category: 'mid-range', starRating: 4,
                description: 'Cozy resort with Himalayan views',
                amenities: ['Free WiFi', 'Mountain View', 'Restaurant', 'Bonfire'],
                roomTypes: [{ name: 'Valley View Room', price: { base: 4500 }, availableRooms: 25 }],
                rating: { average: 4.4, count: 560 }
            }
        ];
        
        const createdHotels = await Hotel.insertMany(hotels);
        console.log(`✅ ${createdHotels.length} hotels created`);
        
        // Create admin user if not exists
        const adminExists = await User.findOne({ email: 'admin@auratravel.com' });
        if (!adminExists) {
            const hashedPassword = await bcrypt.hash('Admin@123', 10);
            await User.create({
                name: 'Admin',
                email: 'admin@auratravel.com',
                password: hashedPassword,
                role: 'admin'
            });
            console.log('✅ Admin user created (email: admin@auratravel.com, password: Admin@123)');
        }
        
        console.log('🎉 Seeding completed!');
        process.exit();
    } catch (error) {
        console.error('❌ Seeding error:', error);
        process.exit(1);
    }
};

seed(); 
// ============================================
// AURA TRAVEL BACKEND - COMBINED SERVER
// ============================================

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const asyncHandler = require('express-async-handler');
const path = require('path');
const fs = require('fs');

// Load env
dotenv.config();

// Initialize Express
const app = express();

// Middleware
app.use(cors({
    origin: ['http://127.0.0.1:5500', 'http://localhost:5500', 'http://localhost:3000'],
    credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Create uploads folder if not exists
if (!fs.existsSync('./uploads')) {
    fs.mkdirSync('./uploads');
}

// ============================================
// DATABASE CONNECTION
// ============================================
const connectDB = async () => {
    try {
        const conn = await mongoose.connect(process.env.MONGODB_URI);
        console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
    } catch (error) {
        console.error(`❌ MongoDB Error: ${error.message}`);
        process.exit(1);
    }
};

// ============================================
// MODELS
// ============================================

// User Model
const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    phone: { type: String },
    password: { type: String, required: true, select: false },
    avatar: { type: String, default: 'default-avatar.jpg' },
    role: { type: String, enum: ['user', 'admin'], default: 'user' },
    savedDestinations: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Destination' }],
    loyaltyPoints: { type: Number, default: 0 },
    memberSince: { type: Date, default: Date.now }
}, { timestamps: true });

userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
});

userSchema.methods.matchPassword = async function(enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
};

userSchema.methods.getSignedJwtToken = function() {
    return jwt.sign({ id: this._id, role: this.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE });
};

const User = mongoose.model('User', userSchema);

// Destination Model
const destinationSchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true },
    state: { type: String, required: true },
    category: { type: String, enum: ['temples', 'mountains', 'beaches', 'monuments', 'wildlife', 'backwaters', 'heritage', 'cities'], required: true },
    type: { type: String },
    description: { type: String, required: true },
    shortDescription: { type: String },
    coordinates: { lat: Number, lng: Number },
    coverImage: { type: String },
    images: [{ url: String, publicId: String }],
    rating: { average: { type: Number, default: 0 }, count: { type: Number, default: 0 } },
    bestTimeToVisit: { months: [String], description: String },
    price: { average: { perDay: { type: Number, default: 0 } } },
    tags: [String],
    isFeatured: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    statistics: { views: { type: Number, default: 0 } }
}, { timestamps: true });

destinationSchema.index({ name: 'text', state: 'text', description: 'text', tags: 'text' });
const Destination = mongoose.model('Destination', destinationSchema);

// Hotel Model
const hotelSchema = new mongoose.Schema({
    name: { type: String, required: true },
    destination: { type: mongoose.Schema.Types.ObjectId, ref: 'Destination' },
    location: {
        address: String,
        city: String,
        state: String,
        coordinates: { lat: Number, lng: Number }
    },
    category: { type: String, enum: ['budget', 'mid-range', 'luxury', 'boutique', 'resort', 'hostel'] },
    starRating: { type: Number, min: 1, max: 5, default: 3 },
    description: String,
    images: [{ url: String }],
    amenities: [String],
    roomTypes: [{
        name: String,
        price: { base: Number, weekend: Number },
        availableRooms: Number
    }],
    rating: { average: { type: Number, default: 0 }, count: { type: Number, default: 0 } },
    isActive: { type: Boolean, default: true }
}, { timestamps: true });

const Hotel = mongoose.model('Hotel', hotelSchema);

// Booking Model
const bookingSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    hotel: { type: mongoose.Schema.Types.ObjectId, ref: 'Hotel', required: true },
    roomType: { name: String, price: Number, quantity: Number },
    checkIn: { type: Date, required: true },
    checkOut: { type: Date, required: true },
    guests: { type: Number, default: 2 },
    totalAmount: { type: Number, required: true },
    status: { type: String, enum: ['pending', 'confirmed', 'cancelled', 'completed'], default: 'pending' },
    bookingId: { type: String, unique: true }
}, { timestamps: true });

const Booking = mongoose.model('Booking', bookingSchema);

// Itinerary Model
const itinerarySchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    name: { type: String, required: true },
    destinations: [String],
    duration: { type: Number, required: true },
    startDate: Date,
    endDate: Date,
    budget: Number,
    days: [{ day: Number, activities: [String] }],
    status: { type: String, enum: ['draft', 'planned', 'completed'], default: 'draft' }
}, { timestamps: true });

const Itinerary = mongoose.model('Itinerary', itinerarySchema);

// Review Model
const reviewSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    destination: { type: mongoose.Schema.Types.ObjectId, ref: 'Destination' },
    hotel: { type: mongoose.Schema.Types.ObjectId, ref: 'Hotel' },
    rating: { type: Number, required: true, min: 1, max: 5 },
    title: String,
    comment: String,
    images: [String],
    helpful: { count: { type: Number, default: 0 }, users: [{ type: mongoose.Schema.Types.ObjectId }] }
}, { timestamps: true });

const Review = mongoose.model('Review', reviewSchema);

// ============================================
// AUTH MIDDLEWARE
// ============================================
const protect = asyncHandler(async (req, res, next) => {
    let token;
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        token = req.headers.authorization.split(' ')[1];
    }
    if (!token) {
        res.status(401);
        throw new Error('Not authorized');
    }
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = await User.findById(decoded.id).select('-password');
        next();
    } catch (error) {
        res.status(401);
        throw new Error('Not authorized');
    }
});

const authorize = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            res.status(403);
            throw new Error('Not authorized for this action');
        }
        next();
    };
};

// ============================================
// AUTH ROUTES
// ============================================
app.post('/api/auth/register', asyncHandler(async (req, res) => {
    const { name, email, password, phone } = req.body;
    
    const userExists = await User.findOne({ email });
    if (userExists) {
        res.status(400);
        throw new Error('User already exists');
    }
    
    const user = await User.create({ name, email, password, phone });
    
    res.status(201).json({
        success: true,
        token: user.getSignedJwtToken(),
        user: {
            id: user._id,
            name: user.name,
            email: user.email,
            avatar: user.avatar,
            role: user.role
        }
    });
}));

app.post('/api/auth/login', asyncHandler(async (req, res) => {
    const { email, password } = req.body;
    
    const user = await User.findOne({ email }).select('+password');
    if (!user) {
        res.status(401);
        throw new Error('Invalid credentials');
    }
    
    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
        res.status(401);
        throw new Error('Invalid credentials');
    }
    
    res.json({
        success: true,
        token: user.getSignedJwtToken(),
        user: {
            id: user._id,
            name: user.name,
            email: user.email,
            avatar: user.avatar,
            role: user.role,
            savedDestinations: user.savedDestinations
        }
    });
}));

app.get('/api/auth/me', protect, asyncHandler(async (req, res) => {
    const user = await User.findById(req.user.id).populate('savedDestinations', 'name state coverImage rating');
    res.json({ success: true, user });
}));

app.put('/api/auth/profile', protect, asyncHandler(async (req, res) => {
    const { name, phone } = req.body;
    const user = await User.findById(req.user.id);
    
    if (name) user.name = name;
    if (phone) user.phone = phone;
    
    await user.save();
    res.json({ success: true, user });
}));

app.post('/api/auth/wishlist/:id', protect, asyncHandler(async (req, res) => {
    const user = await User.findById(req.user.id);
    const destId = req.params.id;
    
    const index = user.savedDestinations.indexOf(destId);
    if (index === -1) {
        user.savedDestinations.push(destId);
    } else {
        user.savedDestinations.splice(index, 1);
    }
    
    await user.save();
    res.json({ success: true, saved: index === -1, savedDestinations: user.savedDestinations });
}));

// ============================================
// DESTINATION ROUTES
// ============================================
app.get('/api/destinations', asyncHandler(async (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;
    
    const query = { isActive: true };
    
    if (req.query.category) query.category = req.query.category;
    if (req.query.state) query.state = req.query.state;
    if (req.query.search) query.$text = { $search: req.query.search };
    if (req.query.featured) query.isFeatured = true;
    
    const sort = req.query.sort === 'rating' ? { 'rating.average': -1 } : { 'statistics.views': -1 };
    
    const destinations = await Destination.find(query).sort(sort).skip(skip).limit(limit);
    const total = await Destination.countDocuments(query);
    
    res.json({
        success: true,
        count: destinations.length,
        total,
        page,
        pages: Math.ceil(total / limit),
        data: destinations
    });
}));

app.get('/api/destinations/featured', asyncHandler(async (req, res) => {
    const destinations = await Destination.find({ isFeatured: true, isActive: true }).limit(10);
    res.json({ success: true, data: destinations });
}));

app.get('/api/destinations/popular', asyncHandler(async (req, res) => {
    const destinations = await Destination.find({ isActive: true })
        .sort({ 'statistics.views': -1, 'rating.average': -1 })
        .limit(10);
    res.json({ success: true, data: destinations });
}));

app.get('/api/destinations/states', asyncHandler(async (req, res) => {
    const states = await Destination.aggregate([
        { $match: { isActive: true } },
        { $group: { _id: '$state', count: { $sum: 1 } } },
        { $sort: { _id: 1 } }
    ]);
    res.json({ success: true, data: states });
}));

app.get('/api/destinations/categories', asyncHandler(async (req, res) => {
    const categories = await Destination.aggregate([
        { $match: { isActive: true } },
        { $group: { _id: '$category', count: { $sum: 1 } } },
        { $sort: { count: -1 } }
    ]);
    res.json({ success: true, data: categories });
}));

app.get('/api/destinations/state/:state', asyncHandler(async (req, res) => {
    const destinations = await Destination.find({ state: req.params.state, isActive: true });
    res.json({ success: true, state: req.params.state, count: destinations.length, data: destinations });
}));

app.get('/api/destinations/category/:category', asyncHandler(async (req, res) => {
    const destinations = await Destination.find({ category: req.params.category, isActive: true });
    res.json({ success: true, category: req.params.category, count: destinations.length, data: destinations });
}));

app.get('/api/destinations/:id', asyncHandler(async (req, res) => {
    const destination = await Destination.findById(req.params.id);
    if (!destination) {
        res.status(404);
        throw new Error('Destination not found');
    }
    destination.statistics.views += 1;
    await destination.save();
    res.json({ success: true, data: destination });
}));
app.get('/api/destinations', async (req, res) => {

    const destinations = await Destination.find();

    res.json({
        success: true,
        data: destinations
    });
});

app.post('/api/destinations', protect, authorize('admin'), asyncHandler(async (req, res) => {
    const destination = await Destination.create(req.body);
    res.status(201).json({ success: true, data: destination });
}));

app.put('/api/destinations/:id', protect, authorize('admin'), asyncHandler(async (req, res) => {
    const destination = await Destination.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, data: destination });
}));

app.delete('/api/destinations/:id', protect, authorize('admin'), asyncHandler(async (req, res) => {
    await Destination.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Destination deleted' });
}));

// ============================================
// HOTEL ROUTES
// ============================================
app.get('/api/hotels', asyncHandler(async (req, res) => {
    const query = { isActive: true };
    
    if (req.query.destination) query.destination = req.query.destination;
    if (req.query.category) query.category = req.query.category;
    if (req.query.minPrice) query['roomTypes.price.base'] = { $gte: parseInt(req.query.minPrice) };
    if (req.query.maxPrice) {
        if (!query['roomTypes.price.base']) query['roomTypes.price.base'] = {};
        query['roomTypes.price.base'].$lte = parseInt(req.query.maxPrice);
    }
    
    const hotels = await Hotel.find(query).populate('destination', 'name state');
    res.json({ success: true, count: hotels.length, data: hotels });
}));

app.get('/api/hotels/:id', asyncHandler(async (req, res) => {
    const hotel = await Hotel.findById(req.params.id).populate('destination', 'name state');
    if (!hotel) {
        res.status(404);
        throw new Error('Hotel not found');
    }
    res.json({ success: true, data: hotel });
}));

app.post('/api/hotels', protect, authorize('admin'), asyncHandler(async (req, res) => {
    const hotel = await Hotel.create(req.body);
    res.status(201).json({ success: true, data: hotel });
}));

// ============================================
// ITINERARY ROUTES
// ============================================
app.get('/api/itineraries', protect, asyncHandler(async (req, res) => {
    const itineraries = await Itinerary.find({ user: req.user.id }).sort('-createdAt');
    res.json({ success: true, count: itineraries.length, data: itineraries });
}));

app.get('/api/itineraries/:id', protect, asyncHandler(async (req, res) => {
    const itinerary = await Itinerary.findOne({ _id: req.params.id, user: req.user.id });
    if (!itinerary) {
        res.status(404);
        throw new Error('Itinerary not found');
    }
    res.json({ success: true, data: itinerary });
}));
app.get('/api/hotels', async (req, res) => {

    const hotels = await Hotel.find();

    res.json({
        success: true,
        data: hotels
    });
});

app.post('/api/itineraries', protect, asyncHandler(async (req, res) => {
    const itinerary = await Itinerary.create({
        ...req.body,
        user: req.user.id
    });
    res.status(201).json({ success: true, data: itinerary });
}));

app.put('/api/itineraries/:id', protect, asyncHandler(async (req, res) => {
    const itinerary = await Itinerary.findOneAndUpdate(
        { _id: req.params.id, user: req.user.id },
        req.body,
        { new: true }
    );
    res.json({ success: true, data: itinerary });
}));

app.delete('/api/itineraries/:id', protect, asyncHandler(async (req, res) => {
    await Itinerary.findOneAndDelete({ _id: req.params.id, user: req.user.id });
    res.json({ success: true, message: 'Itinerary deleted' });
}));

// ============================================
// BOOKING ROUTES
// ============================================
app.get('/api/bookings', protect, asyncHandler(async (req, res) => {
    const bookings = await Booking.find({ user: req.user.id })
        .populate('hotel', 'name location images')
        .sort('-createdAt');
    res.json({ success: true, data: bookings });
}));

app.post('/api/bookings', protect, asyncHandler(async (req, res) => {
    const { hotelId, roomType, checkIn, checkOut, guests } = req.body;
    
    const hotel = await Hotel.findById(hotelId);
    if (!hotel) {
        res.status(404);
        throw new Error('Hotel not found');
    }
    
    const selectedRoom = hotel.roomTypes.find(r => r.name === roomType.name);
    if (!selectedRoom) {
        res.status(400);
        throw new Error('Room type not found');
    }
    
    const nights = Math.ceil((new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24));
    const totalAmount = selectedRoom.price.base * nights * roomType.quantity;
    
    const booking = await Booking.create({
        user: req.user.id,
        hotel: hotelId,
        roomType: { ...roomType, price: selectedRoom.price.base },
        checkIn,
        checkOut,
        guests,
        totalAmount,
        bookingId: `AURA${Date.now()}`
    });
    
    res.status(201).json({ success: true, data: booking });
}));

// ============================================
// REVIEW ROUTES
// ============================================
app.get('/api/reviews/destination/:id', asyncHandler(async (req, res) => {
    const reviews = await Review.find({ destination: req.params.id })
        .populate('user', 'name avatar')
        .sort('-createdAt');
    res.json({ success: true, data: reviews });
}));

app.post('/api/reviews', protect, asyncHandler(async (req, res) => {
    const review = await Review.create({
        ...req.body,
        user: req.user.id
    });
    
    if (req.body.destination) {
        const destination = await Destination.findById(req.body.destination);
        if (destination) {
            destination.rating.count += 1;
            const totalRating = destination.rating.average * (destination.rating.count - 1) + req.body.rating;
            destination.rating.average = totalRating / destination.rating.count;
            await destination.save();
        }
    }
    
    res.status(201).json({ success: true, data: review });
}));

// ============================================
// WEATHER ROUTES (Mock Data)
// ============================================
app.get('/api/weather/:city', asyncHandler(async (req, res) => {
    const weatherData = {
        'Delhi': { temp: 32, condition: 'Sunny', humidity: 45, wind: 12 },
        'Mumbai': { temp: 30, condition: 'Humid', humidity: 70, wind: 8 },
        'Goa': { temp: 31, condition: 'Sunny', humidity: 65, wind: 10 },
        'Manali': { temp: 18, condition: 'Cool', humidity: 40, wind: 5 },
        'Jaipur': { temp: 35, condition: 'Hot', humidity: 30, wind: 6 },
        'Kochi': { temp: 29, condition: 'Cloudy', humidity: 75, wind: 8 }
    };
    
    const city = req.params.city;
    const weather = weatherData[city] || { temp: 28, condition: 'Clear', humidity: 50, wind: 10 };
    
    res.json({ 
        success: true, 
        data: {
            city,
            ...weather,
            forecast: [
                { day: 'Mon', temp: weather.temp - 1, condition: weather.condition },
                { day: 'Tue', temp: weather.temp, condition: weather.condition },
                { day: 'Wed', temp: weather.temp + 1, condition: 'Partly Cloudy' },
                { day: 'Thu', temp: weather.temp - 2, condition: 'Cloudy' },
                { day: 'Fri', temp: weather.temp, condition: weather.condition }
            ]
        }
    });
}));

// ============================================
// AI CONCIERGE ROUTES (Mock)
// ============================================
app.post('/api/ai/chat', protect, asyncHandler(async (req, res) => {
    const { message } = req.body;
    
    const responses = [
        "That's a great question! Based on your interests, I'd recommend visiting Rajasthan for its rich culture and heritage.",
        "The best time to visit India is between October and March when the weather is pleasant.",
        "For a 3-day trip, I suggest the Golden Triangle: Delhi, Agra, and Jaipur.",
        "Kerala backwaters are beautiful in September. The monsoon makes everything lush green!",
        "You should definitely try the local street food in Mumbai and Delhi!",
        "The Taj Mahal looks most beautiful at sunrise. Try to visit early morning to avoid crowds."
    ];
    
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    
    res.json({
        success: true,
        data: {
            response: randomResponse,
            suggestions: [
                "Plan a 3-day trip to Jaipur",
                "Best hotels in Goa under ₹5000",
                "Kerala backwaters itinerary"
            ]
        }
    });
}));

// ============================================
// STATS ROUTE
// ============================================
app.get('/api/stats', asyncHandler(async (req, res) => {
    const destinationCount = await Destination.countDocuments({ isActive: true });
    const stateCount = (await Destination.distinct('state')).length;
    
    res.json({
        success: true,
        data: {
            destinations: destinationCount,
            states: stateCount,
            avgBudget: 6988
        }
    });
}));

// ============================================
// ERROR HANDLER
// ============================================
app.use((err, req, res, next) => {
    const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
    res.status(statusCode).json({
        success: false,
        message: err.message,
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    });
});

// ============================================
// START SERVER
// ============================================
const PORT = process.env.PORT || 5000;

const startServer = async () => {
    await connectDB();
    app.listen(PORT, () => {
        console.log(`🚀 Server running on http://localhost:${PORT}`);
        console.log(`📡 API Endpoints:`);
        console.log(`   POST   http://localhost:${PORT}/api/auth/register`);
        console.log(`   POST   http://localhost:${PORT}/api/auth/login`);
        console.log(`   GET    http://localhost:${PORT}/api/destinations`);
        console.log(`   GET    http://localhost:${PORT}/api/hotels`);
        console.log(`   GET    http://localhost:${PORT}/api/stats`);
    });
};

startServer();